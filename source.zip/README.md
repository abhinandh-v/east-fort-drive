# East Fort Drive — 10 km Explorer

[Play the public browser game](https://abhinandh-v.github.io/east-fort-drive/)

Drive a Defender-inspired SUV on real OpenStreetMap roads within a **10 km radius of East Fort**, Thiruvananthapuram. The region contains 19,987 road sections and 165,687 building footprints. Nearby scenery is loaded into the scene as you travel. Google Maps imagery and data are not embedded.

## Play

WASD or arrows drive; Space brakes. F enters/exits your Defender, C cycles five driving cameras, including a driver’s-seat view, Shift runs on foot, R recovers to the nearest road and repairs the car. M enables/mutes sound, H honks, Tab expands the map and Esc pauses. Touch movement and brake controls are included.

Choose one of eight journeys: Chalai courier, Museum taxi, NH 66 northbound, Coastal evening, Medical supplies, Southern highway ride, City explorer, and Across town express. Routes run from approximately 2 to 16 km of driving. Follow the mint route to amber checkpoints; stop for deliveries or drive through highway checkpoints. Timed tasks have a countdown. Completed journeys award money and a vehicle-condition bonus. Progress stays in this browser.

Use **Ride NH 66** to start on the highway or **East Fort** to return home. Graphics & world contains Low/High/Ultra settings and four vehicle paint choices. Features include HDR reflections, a detailed SUV cabin and wheels, animated suspension/steering, scanned human faces, building windows at night, monsoon rain, vehicle damage, traffic and a road route map. Click Enable sound once for recorded engine, footsteps and rain, with synthesized horn/skid/impact/door effects.

Use **Driver’s view** for the driving position inside the cabin. Cabin glass is hidden in this camera to provide an unobstructed road view and restored for outside cameras. Instructions automatically hide after four seconds; **Clear instructions** or the close button dismisses them immediately. **Instructions / journeys** reopens the controls and journey selector. Trees are checked against all nearby roads, intersections and carriageways with a six-metre clearance beyond the road edge.

## Geographic and visual scope

The map uses OSM road geometry and building footprints projected into metre coordinates around 8.48275 N, 76.94765 E. The source database is supplied as [region.json](./region.json) under ODbL 1.0. Buildings have estimated heights and generated facades. Landmark architecture is interpreted, vegetation is generated, and terrain, bridges and junctions are flattened. Routing permits both directions for gameplay. This is a browser driving game, not a complete digital twin, a navigation service, or GTA V-quality photorealism. No building interiors, police, combat or multiplayer are included. Google Maps cannot be exported into this standalone game under its standard terms, so the reusable map source is OpenStreetMap.

See [world and lighting credits](./WORLD-CREDITS.txt), [human asset credits](./HUMAN-ASSET-CREDITS.txt), and [audio credits](./AUDIO-CREDITS.txt). The generic engine recording is not Defender-specific. The vehicle interpretation is unofficial. Lighting uses a CC0 Poly Haven HDR image for reflections; it is not a photograph of Kerala.

## Source and validation

The root hosts the compiled game; source.zip contains the editable project. Preserve its pnpm lockfile, install dependencies with pnpm, then run `./build.ps1` in PowerShell on Windows. `node serve.mjs` serves dist at the printed local address. The app uses Three.js and React and has no server-side gameplay component.

`node check-region.mjs` validates the 10 km boundary, graph connectivity, highway access and all eight mission routes against the actual data. `node check-expansion.mjs` checks initialization, driving, quick travel, recovery, walking, mission starts, map, weather, quality, pause and cleanup with a mocked renderer. `node check-audio.mjs` validates audio behavior with a mocked AudioContext. Browser integration status checks confirm the dataset and model/HDR loading; these are not a visual review or an audible listening test.

`prepare-map.mjs` rebuilds assets/region.json from the JSON downloaded by fetch-map.mjs. Map data is ODbL; human and audio licenses are in their credit files. React and Three.js license notices accompany the distribution.
