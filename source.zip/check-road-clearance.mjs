import assert from 'node:assert/strict';
import fs from 'node:fs';
import {createRoadClearance} from './app/region.js';
const cross={nodes:[[-100,0],[100,0],[0,-100],[0,100],[-100,18],[100,18]],roads:[{p:[0,1],w:10},{p:[2,3],w:8},{p:[4,5],w:8}]};
const clear=createRoadClearance(cross);
assert(!clear(0,13),'Cross street must reject a tree beside the first road');
assert(!clear(50,13),'Parallel carriageway must reject the tree');
assert(!clear(50,10),'Road shoulder is protected');assert(clear(50,40),'Trees remain possible away from roads');
const data=JSON.parse(fs.readFileSync('assets/region.json','utf8')),realClear=createRoadClearance(data);let count=0;
for(const r of data.roads)for(let i=1;i<r.p.length;i++){const a=data.nodes[r.p[i-1]],b=data.nodes[r.p[i]];assert(!realClear((a[0]+b[0])/2,(a[1]+b[1])/2));count++;}
console.log('PASS: crossing roads, parallel carriageways, shoulder clearance and all '+count+' real road segments exclude trees.');
