import type {Metadata} from 'next';
import './globals.css';
export const metadata:Metadata={title:'East Fort Drive — Trivandrum',description:'Explore a stylized East Fort neighborhood in a 3D browser driving and walking game.'};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><body>{children}</body></html>}
