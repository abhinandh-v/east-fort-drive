// Recorded engine, rain and footsteps; complementary synthesized vehicle Foley.
export function createGameAudio(options={}){
 let ctx,master,compressor,enabled=false,disposed=false,loading,status='off',buffers={},loops={},stepClock=0,lastImpact=-10;
 const shots=new Set(),files={engine:'engine.wav',rain:'rain.mp3',step1:'step1.ogg',step2:'step2.ogg',gunshot:'gunshot.wav'};
 const createContext=options.createContext||(()=>new (window.AudioContext||window.webkitAudioContext)());
 const fetcher=options.fetch||((url)=>fetch(url));
 function gain(value=0){const g=ctx.createGain();g.gain.value=value;return g}
 function loop(name,buffer,rate){const source=ctx.createBufferSource(),volume=gain();source.buffer=buffer;source.loop=true;source.playbackRate.value=rate;source.connect(volume);volume.connect(master);source.start();loops[name]={source,volume};}
 async function initialize(){
  if(!ctx){ctx=createContext();master=gain(0);compressor=ctx.createDynamicsCompressor();compressor.threshold.value=-16;compressor.knee.value=16;compressor.ratio.value=5;compressor.attack.value=.005;compressor.release.value=.2;master.connect(compressor);compressor.connect(ctx.destination)}
  await ctx.resume();
  if(status==='ready')return;
  if(loading)return loading;
  status='loading';
  loading=Promise.all(Object.entries(files).map(async([name,file])=>{const response=await fetcher('./'+file);if(!response.ok)throw new Error('Could not load '+file);const data=await response.arrayBuffer();const buffer=await ctx.decodeAudioData(data);return[name,buffer]})).then(entries=>{
   if(disposed)return;buffers=Object.fromEntries(entries);loop('engine',buffers.engine,.62);loop('rain',buffers.rain,1);loop('traffic',buffers.engine,.83);status='ready';
  }).catch(e=>{if(!disposed){status='error';enabled=false;console.warn('Game audio unavailable',e)}}).finally(()=>{loading=null});
  return loading;
 }
 function silence(){if(master){master.gain.cancelScheduledValues(ctx.currentTime);master.gain.setValueAtTime(0,ctx.currentTime)}}
 function toggle(){enabled=!enabled;if(enabled){void initialize().catch(()=>{enabled=false;status='error'})}else{silence();void ctx?.suspend()}return enabled}
 function effect(type,strength=1){
  if(!enabled||status!=='ready'||ctx.state!=='running')return;
  const now=ctx.currentTime;
  if(type==='gunshot'){const source=ctx.createBufferSource(),volume=gain(.55);source.buffer=buffers.gunshot;source.playbackRate.value=.96+Math.random()*.08;source.connect(volume);volume.connect(master);shots.add(source);source.onended=()=>{shots.delete(source);source.disconnect();volume.disconnect();};source.start();return;}
  if(type==='impact'){if(now-lastImpact<.5)return;lastImpact=now}
  const duration=type==='horn'?.36:type==='door'?.22:.2;
  const out=gain();out.connect(master);out.gain.setValueAtTime(0,now);out.gain.linearRampToValueAtTime(Math.min(.3,strength*.2),now+.008);out.gain.exponentialRampToValueAtTime(.001,now+duration);
  const nodes=[];
  if(type==='horn'){
   for(const hz of [350,440]){const oscillator=ctx.createOscillator();oscillator.type='sawtooth';oscillator.frequency.value=hz;const filter=ctx.createBiquadFilter();filter.type='lowpass';filter.frequency.value=1800;oscillator.connect(filter);filter.connect(out);oscillator.start();oscillator.stop(now+duration);nodes.push(oscillator,filter)}
  }else{
   const oscillator=ctx.createOscillator();oscillator.type='sine';oscillator.frequency.setValueAtTime(type==='door'?130:75,now);oscillator.frequency.exponentialRampToValueAtTime(35,now+duration);oscillator.connect(out);oscillator.start();oscillator.stop(now+duration);nodes.push(oscillator);
   const b=ctx.createBuffer(1,Math.ceil(ctx.sampleRate*duration),ctx.sampleRate),data=b.getChannelData(0);for(let i=0;i<data.length;i++)data[i]=(Math.random()*2-1)*Math.exp(-i/data.length*8)*.55;const n=ctx.createBufferSource();n.buffer=b;const filter=ctx.createBiquadFilter();filter.type='lowpass';filter.frequency.value=type==='door'?900:1600;n.connect(filter);filter.connect(out);n.start();nodes.push(n,filter);
  }
  const source=nodes[0];shots.add(source);source.onended=()=>{shots.delete(source);nodes.forEach(n=>n.disconnect());out.disconnect()};
 }
 let alternate=0,skid,v8;
 function startV8(){const volume=gain(),filter=ctx.createBiquadFilter();filter.type='lowpass';filter.frequency.value=420;const nodes=[1,2,3].map((multiple,i)=>{const o=ctx.createOscillator(),v=gain([.6,.22,.1][i]);o.type=i===0?'sawtooth':'sine';o.frequency.value=48*multiple;o.connect(v);v.connect(filter);o.start();return{o,v,multiple};});filter.connect(volume);volume.connect(master);v8={volume,filter,nodes};}

 function startSkid(){const b=ctx.createBuffer(1,ctx.sampleRate,ctx.sampleRate),data=b.getChannelData(0);for(let i=0;i<data.length;i++)data[i]=(Math.random()*2-1);const source=ctx.createBufferSource();source.buffer=b;source.loop=true;const filter=ctx.createBiquadFilter();filter.type='bandpass';filter.frequency.value=1650;filter.Q.value=3;const volume=gain();source.connect(filter);filter.connect(volume);volume.connect(master);source.start();skid={source,filter,volume}}
 function step(){const source=ctx.createBufferSource();source.buffer=buffers[(alternate++%2)?'step1':'step2'];source.playbackRate.value=.92+Math.random()*.16;const volume=gain(.75);source.connect(volume);volume.connect(master);shots.add(source);source.onended=()=>{shots.delete(source);source.disconnect();volume.disconnect()};source.start()}
 function tick(state,dt,nearTraffic=0){
  if(!ctx||status!=='ready')return;
  const now=ctx.currentTime,audible=enabled&&!state.paused;
  master.gain.setTargetAtTime(audible?.5:0,now,.04);
  if(!audible)return;
  const speed=Math.abs(state.speed),driving=state.mode==='Driving';
  // A small RPM drop at each simulated shift avoids a single steadily rising pitch.
  const gear=Math.min(4,Math.floor(speed/6)),rpm=.58+(speed%6)/6*.48+gear*.095+(state.throttle?.10:0);
  loops.engine.source.playbackRate.setTargetAtTime(rpm,now,.18);
  loops.engine.volume.gain.setTargetAtTime(driving?.23+Math.min(speed/27,1)*.2:0,now,.14);
  loops.rain.volume.gain.setTargetAtTime(state.rain?(driving?.22:.4):0,now,.4);
  loops.traffic.volume.gain.setTargetAtTime(Math.min(nearTraffic,1)*(driving?.07:.16),now,.18);
  if(!v8)startV8();const octa=driving&&(!state.vehicleName||state.vehicleName.includes('OCTA'));const revolutions=750+(speed%7)/7*2500+Math.min(7,Math.floor(speed/7))*210+(state.throttle?850:0);v8.nodes.forEach(({o,multiple})=>o.frequency.setTargetAtTime(revolutions/60*4*multiple,now,.13));v8.filter.frequency.setTargetAtTime(state.throttle?1000:250,now,.1);v8.volume.gain.setTargetAtTime(octa?(state.cam===4?.075:.13)*(state.throttle?1.4:1):0,now,.1);
  if(!skid)startSkid();skid.volume.gain.setTargetAtTime(driving&&state.braking&&speed>6?Math.min(.14,speed*.005):0,now,.045);
  if(!driving&&speed>.5){stepClock+=dt;const interval=speed>5?.29:.43;if(stepClock>=interval){stepClock%=interval;step()}}else stepClock=.2;
 }
 function dispose(){disposed=true;enabled=false;silence();Object.values(loops).forEach(l=>{l.source.stop();l.source.disconnect();l.volume.disconnect()});if(skid){skid.source.stop();skid.source.disconnect();skid.filter.disconnect();skid.volume.disconnect()}if(v8){v8.nodes.forEach(({o,v})=>{o.stop();o.disconnect();v.disconnect();});v8.filter.disconnect();v8.volume.disconnect();}shots.forEach(s=>{try{s.stop()}catch{}});shots.clear();master?.disconnect();compressor?.disconnect();void ctx?.close()}
 return{toggle,tick,effect,silence,dispose,getStatus:()=>({enabled,status,context:ctx?.state||'not-started',loaded:Object.keys(buffers)})};
}
