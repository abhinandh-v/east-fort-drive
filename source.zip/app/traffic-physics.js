// Two circles approximate each car's footprint without a wide circular exclusion zone.
function circles(body){const angle=body.angle||0,offset=body.walking?0:1.08,r=body.walking?.34:1.03;return (body.walking?[0]:[-1,1]).map(s=>({x:body.x+Math.sin(angle)*offset*s,z:body.z+Math.cos(angle)*offset*s,r}));}
export function contact(a,b){let result=null;for(const p of circles(a))for(const q of circles(b)){const dx=p.x-q.x,dz=p.z-q.z,d=Math.hypot(dx,dz),depth=p.r+q.r-d;if(depth>0&&(!result||depth>result.depth)){const fallback=Math.cos(a.angle||0);result={depth,nx:d>1e-6?dx/d:fallback,nz:d>1e-6?dz/d:-Math.sin(a.angle||0)};}}return result;}
export function resolveVehicleMove(start,end,others,valid=()=>true){
 let p={...start},hit=false;const length=Math.hypot(end.x-start.x,end.z-start.z),steps=Math.max(1,Math.ceil(length/.3));
 for(let step=0;step<steps;step++){let candidate={...p,x:p.x+(end.x-start.x)/steps,z:p.z+(end.z-start.z)/steps};
  for(let iteration=0;iteration<8;iteration++){let changed=false;for(const other of others){const c=contact(candidate,other);if(!c)continue;hit=true;const previous=contact(p,other);
    // An existing overlap must never reject motion that moves out of it.
    if(previous&&c.depth<previous.depth-1e-7)continue;
    const projected={...candidate,x:candidate.x+c.nx*(c.depth+.008),z:candidate.z+c.nz*(c.depth+.008)};
    if(valid(projected.x,projected.z)){candidate=projected;changed=true;}
    else{candidate={...p};}
   }if(!changed)break;}
  if(valid(candidate.x,candidate.z))p=candidate;
 }
 return{x:p.x,z:p.z,hit,moved:Math.hypot(p.x-start.x,p.z-start.z)};
}
export function obstacleAhead(car,other,distance=7){const dx=other.x-car.x,dz=other.z-car.z,forward=dx*Math.sin(car.angle)+dz*Math.cos(car.angle),side=dx*Math.cos(car.angle)-dz*Math.sin(car.angle);return forward>0&&forward<distance&&Math.abs(side)<1.9;}
