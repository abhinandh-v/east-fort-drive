import * as T from 'three';
import {createRoadClearance} from './region.js';
export const VILLAGES=[{id:'grove',name:'Coconut Grove',x:4100,z:1800},{id:'garden',name:'Garden Village',x:4700,z:-1400},{id:'southern',name:'Southern Hamlet',x:2200,z:4700}];
export function addVillages(scene,data,network,region){
 const clear=createRoadClearance(data,9),villages=VILLAGES.map(v=>({...v,...network.nearest(v.x,v.z),houses:0}));
 const mat=c=>new T.MeshStandardMaterial({color:c,roughness:.92}),tile=mat('#9b5137'),timber=mat('#634733'),white=mat('#dacfa9'),green=mat('#3e653c');
 const block=(g,x,y,z,w,h,d,m)=>{const o=new T.Mesh(new T.BoxGeometry(w,h,d),m);o.position.set(x,y,z);o.castShadow=o.receiveShadow=true;g.add(o);return o;};
 const occupied=[];
 for(const v of villages){const group=new T.Group();group.name=v.name;scene.add(group);v.group=group;
  for(let i=0;i<20;i++)for(let attempt=0;attempt<32;attempt++){const theta=(i*2.399+attempt*.49),radius=35+i*8+attempt*3,x=v.x+Math.sin(theta)*radius,z=v.z+Math.cos(theta)*radius;if(!clear(x,z)||region.buildingAt(x,z,7)||region.isWater(x,z)||occupied.some(p=>Math.hypot(x-p.x,z-p.z)<19))continue;
   const g=new T.Group();g.position.set(x,0,z);g.rotation.y=theta+.3;group.add(g);occupied.push({x,z,angle:g.rotation.y});v.houses++;const wall=mat(['#e5d5ad','#acbda6','#d5b5a0','#bfc6c4'][i%4]);block(g,0,1.4,0,7,2.8,5,wall);
   const shape=new T.Shape();shape.moveTo(-4,0);shape.lineTo(0,1.8);shape.lineTo(4,0);shape.closePath();const roof=new T.Mesh(new T.ExtrudeGeometry(shape,{depth:6,bevelEnabled:false}),tile);roof.position.set(0,2.8,-3);g.add(roof);roof.castShadow=true;
   for(const side of[-1,1]){block(g,side*2.3,1.65,-2.54,1.05,1.05,.12,timber);for(let j=0;j<3;j++)block(g,side*2.3-.35+j*.35,1.65,-2.63,.035,1,.04,white);block(g,side*3,1.3,-3.8,.13,2.6,.13,timber);}
   block(g,0,.15,-3.35,7,.3,2.1,white);block(g,0,2.62,-3.6,7.5,.15,2.2,tile);block(g,0,1.05,-2.57,1,2.1,.14,timber);
   for(let j=0;j<6;j++)block(g,-3+j*1.2,.5,-5.7,.10,1,.10,timber);block(g,0,.65,-5.7,7,.08,.08,timber);
   if(i%3===0){const well=new T.Mesh(new T.CylinderGeometry(.75,.75,.8,16,1,true),white);well.position.set(5,.4,0);g.add(well);block(g,5,.05,0,1,.06,1,mat('#1a3941'));}
   if(i%2===0){for(const side of[-1,1])block(g,side*2,1.2,4,.06,2.4,.06,timber);block(g,0,2.2,4,4,.02,.02,timber);for(let k=0;k<3;k++)block(g,k-1,1.85,4,.6,.65,.025,mat(['#769da9','#a7776d','#d0c599'][k]));}
   for(let k=0;k<3;k++){const shrub=new T.Mesh(new T.SphereGeometry(.8,10,8),green);shrub.position.set(-4.5,.65,k*2-2);g.add(shrub);}break;
  }
 }
 return{villages,buildingAt(x,z,r=.7){return occupied.some(h=>{const dx=x-h.x,dz=z-h.z,lx=dx*Math.cos(h.angle)-dz*Math.sin(h.angle),lz=dx*Math.sin(h.angle)+dz*Math.cos(h.angle);return Math.abs(lx)<3.5+r&&lz> -4.5-r&&lz<2.5+r;});},update(x,z){for(const v of villages)v.group.visible=Math.hypot(v.x-x,v.z-z)<1000;},place(x,z){return villages.find(v=>Math.hypot(v.x-x,v.z-z)<300)?.name;}};
}
