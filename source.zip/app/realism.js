import {clothMaterial,skinMaterial,anatomicalForearm,garment,seam} from './wardrobe.js';
import * as T from 'three';
import {createSuspension} from './driving.js';
import {RoundedBoxGeometry} from 'three/addons/geometries/RoundedBoxGeometry.js';
import {GLTFLoader} from 'three/addons/loaders/GLTFLoader.js';

const rubber=new T.MeshStandardMaterial({color:'#181d1e',roughness:.94});
const trim=new T.MeshStandardMaterial({color:'#242d2d',roughness:.5});
const alloy=new T.MeshStandardMaterial({color:'#a3adb0',metalness:.85,roughness:.25});
const glass=new T.MeshPhysicalMaterial({color:'#7896a1',metalness:.2,roughness:.1,transparent:true,opacity:.67,clearcoat:1,side:T.DoubleSide});
const sphere=new T.SphereGeometry(1,20,14);
function part(parent,geometry,material,x,y,z){const m=new T.Mesh(geometry,material);m.position.set(x,y,z);m.castShadow=true;m.receiveShadow=true;parent.add(m);return m}
function rounded(parent,x,y,z,w,h,d,material,r=.04){return part(parent,new RoundedBoxGeometry(w,h,d,2,r),material,x,y,z)}
function ellipsoid(parent,x,y,z,sx,sy,sz,material){const m=part(parent,sphere,material,x,y,z);m.scale.set(sx,sy,sz);return m}

export function createDefender(){
 const root=new T.Group();root.name='Defender 110 inspired SUV';
 const body=new T.Group();root.add(body);
 const paint=new T.MeshPhysicalMaterial({color:'#596d66',metalness:.55,roughness:.29,clearcoat:1,clearcoatRoughness:.18});
 const roofPaint=new T.MeshStandardMaterial({color:'#d4d3c8',metalness:.25,roughness:.32});
 rounded(body,0,.72,0,2.03,.26,4.65,trim,.07);
 rounded(body,0,1.2,0,2.02,.81,4.7,paint,.09);
 rounded(body,0,1.51,-.43,1.98,.31,3.38,paint,.07);
 for(const side of [-1,1])for(const z of [1.24,.18,-.88,-2.08])rounded(body,side*.95,2,z,.085,.78,.10,paint,.02);
 const leather=new T.MeshStandardMaterial({color:'#393c35',roughness:.88});
 for(const z of [.25,-.9])for(const x of [-.5,.5]){rounded(body,x,1.2,z,.72,.17,.7,leather,.08);const back=rounded(body,x,1.55,z-.33,.72,.68,.17,leather,.09);back.rotation.x=-.08;rounded(body,x,1.99,z-.36,.32,.24,.13,leather,.06);}
 rounded(body,0,1.61,1.03,1.78,.22,.39,trim,.06);
 const steering=new T.Group();steering.position.set(-.51,1.73,.77);steering.rotation.x=-.35;body.add(steering);part(steering,new T.TorusGeometry(.19,.022,8,32),leather,0,0,0);rounded(steering,0,0,0,.07,.24,.035,alloy,.01);
 const display=new T.MeshStandardMaterial({color:'#111d25',emissive:'#7399a1',emissiveIntensity:.3});rounded(body,0,1.75,.811,.31,.19,.015,display,.01);
 rounded(body,0,2.43,-.43,2.05,.12,3.52,roofPaint,.05);
 rounded(body,0,1.62,1.77,1.97,.14,1.18,paint);
 const wind=rounded(body,0,2.01,1.272,1.76,.65,.028,glass,.025);wind.rotation.x=-.1;
 rounded(body,0,2.03,-2.137,1.62,.64,.028,glass,.025);
 for(const side of [-1,1]){
  for(const z of [.65,-.42]){rounded(body,side*1.017,1.31,z,.012,.024,.83,trim,.003);rounded(body,side*1.019,1.64,z,.015,.025,.89,alloy,.005);}
  for(const [z,l] of [[.7,.94],[-.38,.94],[-1.48,.8]])rounded(body,side*1.004,2.01,z,.026,.65,l,glass,.02);
  for(const z of [.22,-.86])rounded(body,side*1.025,1.5,z,.035,.06,.27,trim,.01);
  for(const z of [.16,-.9])rounded(body,side*1.02,1.21,z,.024,.78,.018,trim,.006);
  rounded(body,side*1.11,1.88,1.07,.25,.22,.3,trim,.04);
  rounded(body,side*.8,2.56,-.47,.045,.15,3.15,trim,.018);
  rounded(body,side*1.04,.63,-.12,.19,.1,2.2,alloy,.025);
  for(const z of [-1.5,1.5]){const arch=part(body,new T.TorusGeometry(.61,.095,8,24,Math.PI),trim,side*1.02,.62,z);arch.rotation.y=Math.PI/2;}
 }
 for(const x of [-.58,.23]){const wiper=rounded(body,x,1.77,1.305,.025,.027,.57,trim,.005);wiper.rotation.y=.85;}
 rounded(body,0,2.55,-1.98,.055,.2,.06,trim,.01);
 rounded(body,0,.64,2.31,1.25,.16,.39,alloy,.035);
 rounded(body,0,1.18,2.37,1.3,.4,.055,trim);
 for(let i=0;i<5;i++)rounded(body,0,1.02+i*.075,2.41,1.23,.018,.024,alloy,.006);
 rounded(body,0,.78,2.4,2.1,.25,.21,trim,.04);rounded(body,0,.76,-2.42,2.1,.28,.22,trim,.04);
 rounded(body,0,.81,2.52,.5,.13,.018,new T.MeshStandardMaterial({color:'#dedcc6'}),.012);
 const running=new T.MeshStandardMaterial({color:'#fff6d7',emissive:'#fff1cc',emissiveIntensity:2.2});
 for(const x of [-.77,.77]){const ring=part(body,new T.TorusGeometry(.17,.028,8,24),running,x,1.36,2.4);part(body,new T.CircleGeometry(.138,24),glass,x,1.36,2.403)}
 const brakeMat=new T.MeshStandardMaterial({color:'#ac1716',emissive:'#ed2420',emissiveIntensity:.4});
 for(const x of [-.85,.85])for(const y of [1.11,1.55])rounded(body,x,y,-2.377,.16,.23,.05,brakeMat,.04);
 const badgeCanvas=document.createElement('canvas');badgeCanvas.width=512;badgeCanvas.height=64;const badgeCtx=badgeCanvas.getContext('2d');badgeCtx.fillStyle='#596d66';badgeCtx.fillRect(0,0,512,64);badgeCtx.fillStyle='#e2e5de';badgeCtx.font='bold 36px Arial';badgeCtx.textAlign='center';badgeCtx.fillText('D E F E N D E R',256,46);const badgeTex=new T.CanvasTexture(badgeCanvas);badgeTex.colorSpace=T.SRGBColorSpace;part(body,new T.PlaneGeometry(1.12,.14),new T.MeshBasicMaterial({map:badgeTex}),0,1.625,2.365);
 const wheels=[];
 function wheel(parent,x,y,z,spare=false){const pivot=new T.Group();pivot.position.set(x,y,z);parent.add(pivot);const spin=new T.Group();pivot.add(spin);
  const tire=part(spin,new T.CylinderGeometry(.55,.55,.29,32),rubber,0,0,0);tire.rotation.z=Math.PI/2;
  const hub=part(spin,new T.CylinderGeometry(.34,.34,.305,24),alloy,0,0,0);hub.rotation.z=Math.PI/2;
  for(const s of[-1,1]){const sidewall=part(spin,new T.TorusGeometry(.44,.027,8,40),rubber,s*.154,0,0);sidewall.rotation.y=Math.PI/2;for(let b=0;b<5;b++){const a=b*Math.PI*2/5;ellipsoid(spin,s*.17,Math.sin(a)*.09,Math.cos(a)*.09,.013,.018,.018,alloy);}}
  for(const side of [-1,1])for(let i=0;i<5;i++){const a=i*Math.PI*2/5;const spoke=rounded(spin,side*.163,Math.sin(a)*.2,Math.cos(a)*.2,.027,.08,.35,trim,.014);spoke.rotation.x=-a}
  for(let i=0;i<28;i++){const a=i*Math.PI*2/28;const tread=rounded(spin,0,Math.cos(a)*.546,Math.sin(a)*.546,.30,.042,.10,rubber,.008);tread.rotation.x=a}
  if(spare){pivot.rotation.y=Math.PI/2}else wheels.push({pivot,spin,front:z>0});return pivot;
 }
 for(const side of [-1,1])for(const z of [-1.5,1.5])wheel(root,side*1.02,.59,z);
 wheel(body,0,1.53,-2.57,true);
 const headlights=[];for(const x of [-.76,.76]){const light=new T.SpotLight('#fff1d2',0,65,.4,.45,1.4);light.position.set(x,1.33,2.2);light.target.position.set(x,.1,42);root.add(light,light.target);headlights.push(light)}
 const suspension=createSuspension();const cabinGlass=[];body.traverse(o=>{if(o.isMesh&&o.material===glass&&o.position.y>1.8)cabinGlass.push(o);});
 return{g:root,wheels,body,steering,brakeMat,headlights,cabinGlass,resetSuspension(){suspension.reset();},setDriverView(active){cabinGlass.forEach(pane=>pane.visible=!active);},animate(speed,steer,brake,night,dt,time,forces={}){const ride=suspension.step({x:root.position.x,z:root.position.z,angle:root.rotation.y,speed,...forces},dt);for(let i=0;i<wheels.length;i++){const w=wheels[i];w.spin.rotation.x+=speed*dt/.55;w.pivot.rotation.y=w.front?(forces.steering??steer*.53):0;w.pivot.position.y=.59+ride.wheels[i];}body.rotation.z=ride.roll;body.rotation.x=ride.pitch;body.position.y=ride.heave;brakeMat.emissiveIntensity=brake?4:night?1.2:.25;headlights.forEach(l=>l.intensity=night?65:0)}};

}

export function createHuman(shirtColor='#5d6654',trouserColor='#253343'){
 const g=new T.Group();g.name='Human character';g.userData.characterStyle='Tailored field shirt and dark denim';
 const skin=skinMaterial(),shirt=clothMaterial(shirtColor),trousers=clothMaterial(trouserColor,'denim'),shoe=new T.MeshStandardMaterial({color:'#312b26',roughness:.72}),sole=new T.MeshStandardMaterial({color:'#bdb5a2',roughness:.95}),button=new T.MeshStandardMaterial({color:'#292e29',roughness:.5});
 const torso=garment([[.91,.177,.112],[.96,.19,.123],[1.04,.178,.12],[1.14,.184,.128],[1.25,.222,.143],[1.34,.239,.137],[1.40,.232,.119],[1.45,.18,.092],[1.485,.077,.067]],shirt);torso.name='Tailored woven shirt';g.add(torso);
 const hips=garment([[.85,.172,.121],[.90,.188,.13],[.96,.185,.125],[.99,.175,.118]],trousers);g.add(hips);
 const belt=garment([[.938,.191,.13],[.969,.184,.126]],shoe,{fold:0});g.add(belt);rounded(g,0,.954,.135,.047,.028,.013,alloy,.003);
 for(const side of[-1,1]){for(const x of[.09,.165])rounded(g,side*x,.958,.12,.013,.043,.012,trousers,.003);const collar=rounded(g,side*.053,1.452,.072,.081,.095,.012,shirt,.005);collar.rotation.z=side*.35;collar.rotation.x=-.25;
 const pocket=rounded(g,side*.117,1.281,.145,.106,.119,.013,shirt,.006);rounded(g,side*.117,1.336,.152,.112,.027,.014,shirt,.004);seam(g,[[side*.065,1.322,.154],[side*.065,1.229,.154],[side*.117,1.217,.154],[side*.167,1.229,.154],[side*.167,1.322,.154]],'#7b806b');}
 rounded(g,0,1.215,.144,.022,.43,.014,shirt,.004);for(let i=0;i<6;i++)ellipsoid(g,0,1.04+i*.065,.155,.0045,.0045,.003,button);
 seam(g,[[-.168,.929,.07],[0,.923,.121],[.168,.929,.07]],'#7e846d');
 const headMount=new T.Group();headMount.position.y=1.35;g.add(headMount);const fallback=new T.Group();headMount.add(fallback);ellipsoid(fallback,0,.33,0,.102,.14,.105,skin);ellipsoid(fallback,0,.18,0,.061,.094,.061,skin);ellipsoid(fallback,0,.398,-.014,.104,.076,.105,new T.MeshStandardMaterial({color:'#28221f',roughness:1}));
 const limbs=[];for(const side of[-1,1]){
  const leg=new T.Group();leg.position.set(side*.101,.94,0);g.add(leg);const thigh=garment([[-.445,.071,.079],[-.40,.078,.084],[-.31,.088,.094],[-.19,.099,.104],[-.07,.103,.111],[.025,.096,.107]],trousers,{fold:.0025});leg.add(thigh);
  seam(leg,[[side*.10,-.08,0],[side*.094,-.23,0],[side*.075,-.42,0]],'#897c63');
  const knee=new T.Group();knee.position.y=-.43;leg.add(knee);knee.add(garment([[-.43,.063,.068],[-.39,.062,.067],[-.33,.065,.074],[-.24,.071,.082],[-.13,.074,.087],[-.035,.073,.081],[.022,.071,.079]],trousers,{fold:.002}));
  seam(knee,[[side*.073,0,0],[side*.071,-.23,0],[side*.064,-.41,0]],'#897c63');
  rounded(knee,0,-.463,.054,.16,.038,.29,sole,.017);rounded(knee,0,-.424,.048,.15,.075,.272,shoe,.031);rounded(knee,0,-.388,.027,.10,.058,.14,shoe,.021);
  for(let lace=0;lace<4;lace++){seam(knee,[[-.042,-.355-lace*.005,.003+lace*.028],[.043,-.355-lace*.005,.023+lace*.028]],'#bcb6a9',.0022);}
  const arm=new T.Group();arm.position.set(side*.226,1.397,0);arm.rotation.z=side*.06;g.add(arm);arm.add(garment([[-.278,.058,.062],[-.245,.068,.071],[-.18,.071,.077],[-.08,.080,.081],[.015,.072,.075]],shirt,{fold:.002}));const cuff=garment([[-.275,.062,.066],[-.244,.066,.071]],shirt,{fold:.0005});arm.add(cuff);
  const elbow=new T.Group();elbow.position.y=-.27;arm.add(elbow);elbow.add(anatomicalForearm(skin,side));
  if(side===-1){const band=part(elbow,new T.TorusGeometry(.036,.006,8,24),shoe,0,-.225,0);band.rotation.x=Math.PI/2;rounded(elbow,0,-.224,.038,.034,.040,.008,alloy,.007);rounded(elbow,0,-.224,.044,.027,.031,.003,button,.006);}
  limbs.push({side,leg,knee,arm,elbow});
 }
 let armed=false,seated=false;return{g,headMount,fallback,limbs,skin,shirt,setArmed(v){armed=v;},poseSeated(){seated=true;for(const l of limbs){l.leg.rotation.x=-1.45;l.knee.rotation.x=1.4;l.arm.visible=false;}},animate(time,speed){if(seated)return;const moving=Math.min(Math.abs(speed)/3,1),phase=time*(Math.abs(speed)>5?11:7.5);for(const l of limbs){const swing=Math.sin(phase+(l.side>0?Math.PI:0))*moving;l.leg.rotation.x=swing*.43;l.knee.rotation.x=Math.max(0,-swing)*.66;l.arm.rotation.x=-swing*.30;l.elbow.rotation.x=-.12-Math.max(0,swing)*.18;}if(armed)for(const l of limbs){l.arm.rotation.x=-1.3;l.elbow.rotation.x=-.16;l.arm.rotation.z=l.side*.1;}torso.scale.z=1+Math.sin(time*1.7)*.005;torso.rotation.z=Math.sin(phase)*moving*.009;headMount.rotation.y=Math.sin(time*.55)*.035;g.position.y=Math.abs(Math.sin(phase))*moving*.017;}};
}

export async function loadScannedHeads(humans,isDisposed){
 const loader=new GLTFLoader();const tex=new T.TextureLoader();
 const [gltf,color,normal]=await Promise.all([loader.loadAsync('./human-head.glb'),tex.loadAsync('./human-color.jpg'),tex.loadAsync('./human-normal.jpg')]);
 color.colorSpace=T.SRGBColorSpace;
 let geometry;gltf.scene.traverse(o=>{if(o.isMesh&&!geometry)geometry=o.geometry});
 if(!geometry)throw new Error('Human scan contains no mesh');
 const material=new T.MeshStandardMaterial({map:color,normalMap:normal,normalScale:new T.Vector2(.6,.6),roughness:.65});
 geometry.computeBoundingBox();const bound=geometry.boundingBox,scale=.46/(bound.max.y-bound.min.y);
 if(isDisposed()){geometry.dispose();material.dispose();color.dispose();normal.dispose();return}
 for(const h of humans){const mesh=new T.Mesh(geometry,material);mesh.scale.setScalar(scale);mesh.position.y=-bound.min.y*scale;mesh.castShadow=true;h.headMount.add(mesh);h.fallback.visible=false}
 return[color,normal];
}

export function weatherMaterials(materials){
 for(const [color,m] of materials){if(['#50585a','#b9b4a0','#848866','#cdbb93','#dfc798','#83aaa6','#cfa388','#b6bfab','#dfd6b7','#e7e2cc','#d7cfb6'].includes(color)){
 m.roughness=color==='#50585a'?.84:.95;m.onBeforeCompile=shader=>{shader.vertexShader='varying vec3 efWorld;\n'+shader.vertexShader;shader.vertexShader=shader.vertexShader.replace('#include <worldpos_vertex>','#include <worldpos_vertex>\nefWorld=(modelMatrix*vec4(transformed,1.0)).xyz;');shader.fragmentShader='varying vec3 efWorld;\nfloat efNoise(vec3 p){return fract(sin(dot(p,vec3(12.9898,78.233,37.719)))*43758.5453);}\n'+shader.fragmentShader;shader.fragmentShader=shader.fragmentShader.replace('#include <color_fragment>','#include <color_fragment>\nfloat grain=efNoise(floor(efWorld*48.0)); float stain=efNoise(floor(efWorld*1.3)); diffuseColor.rgb*=mix(0.84,1.08,grain)*mix(0.91,1.04,stain);')};
 }}
}

export function createAtmosphere(scene){
 const uniforms={day:{value:1}};
 const sky=new T.Mesh(new T.SphereGeometry(650,32,16),new T.ShaderMaterial({side:T.BackSide,depthWrite:false,uniforms,vertexShader:'varying vec3 vDir;void main(){vDir=position;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.0);}',fragmentShader:`varying vec3 vDir;uniform float day;
 float hash(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453);}float noise(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);return mix(mix(hash(i),hash(i+vec2(1,0)),f.x),mix(hash(i+vec2(0,1)),hash(i+1.),f.x),f.y);}
 void main(){vec3 d=normalize(vDir);float h=max(d.y,0.);vec3 c=mix(vec3(.83,.81,.73),vec3(.27,.49,.65),pow(h,.45));float n=noise(d.xz/(h+.12)*2.)*.65+noise(d.xz/(h+.12)*5.)*.35;float cloud=smoothstep(.55,.75,n)*smoothstep(.03,.25,h);c=mix(c,vec3(.92,.91,.86),cloud*.8);float sun=pow(max(dot(d,normalize(vec3(-90.,140.,65.))),0.),850.);c+=vec3(1.,.78,.45)*sun*2.;c=mix(vec3(.025,.047,.078)+vec3(.04,.07,.10)*h,c,day);gl_FragColor=vec4(c,1.);}` }));scene.add(sky);
 const faces=[];for(let i=0;i<6;i++){const c=document.createElement('canvas');c.width=c.height=64;const ctx=c.getContext('2d');const grad=ctx.createLinearGradient(0,0,0,64);grad.addColorStop(0,i===3?'#68715e':'#8da6b8');grad.addColorStop(.65,'#d3d3c4');grad.addColorStop(1,'#6a705e');ctx.fillStyle=grad;ctx.fillRect(0,0,64,64);faces.push(c)}
 const env=new T.CubeTexture(faces);env.colorSpace=T.SRGBColorSpace;env.needsUpdate=true;scene.environment=env;scene.environmentIntensity=.8;
 return{setNight(n){uniforms.day.value=n?0:1;scene.environmentIntensity=n?.09:.8},dispose(){env.dispose()}};
}
