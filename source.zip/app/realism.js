import * as T from 'three';
import {RoundedBoxGeometry} from 'three/addons/geometries/RoundedBoxGeometry.js';
import {GLTFLoader} from 'three/addons/loaders/GLTFLoader.js';

const rubber=new T.MeshStandardMaterial({color:'#181d1e',roughness:.94});
const trim=new T.MeshStandardMaterial({color:'#242d2d',roughness:.5});
const alloy=new T.MeshStandardMaterial({color:'#a3adb0',metalness:.85,roughness:.25});
const glass=new T.MeshPhysicalMaterial({color:'#7896a1',metalness:.2,roughness:.1,transparent:true,opacity:.67,clearcoat:1,side:T.DoubleSide});
const sphere=new T.SphereGeometry(1,20,14);
function part(parent,geometry,material,x,y,z){const m=new T.Mesh(geometry,material);m.position.set(x,y,z);m.castShadow=true;m.receiveShadow=true;parent.add(m);return m}
function rounded(parent,x,y,z,w,h,d,material,r=.04){return part(parent,new RoundedBoxGeometry(w,h,d,2,r),material,x,y,z)}
function ellipsoid(parent,x,y,z,sx,sy,sz,material){const m=part(parent,sphere,material,x,y,z);m.scale.set(sx,sy,sz);return m}

export function createDefender(){
 const root=new T.Group();root.name='Defender 110 inspired SUV';
 const body=new T.Group();root.add(body);
 const paint=new T.MeshPhysicalMaterial({color:'#596d66',metalness:.55,roughness:.29,clearcoat:1,clearcoatRoughness:.18});
 const roofPaint=new T.MeshStandardMaterial({color:'#d4d3c8',metalness:.25,roughness:.32});
 rounded(body,0,.72,0,2.03,.26,4.65,trim,.07);
 rounded(body,0,1.2,0,2.02,.81,4.7,paint,.09);
 rounded(body,0,1.87,-.43,1.98,1.05,3.38,paint,.08);
 rounded(body,0,2.43,-.43,2.05,.12,3.52,roofPaint,.05);
 rounded(body,0,1.62,1.77,1.97,.14,1.18,paint);
 const wind=rounded(body,0,2.01,1.272,1.76,.65,.028,glass,.025);wind.rotation.x=-.1;
 rounded(body,0,2.03,-2.137,1.62,.64,.028,glass,.025);
 for(const side of [-1,1]){
  for(const [z,l] of [[.7,.94],[-.38,.94],[-1.48,.8]])rounded(body,side*1.004,2.01,z,.026,.65,l,glass,.02);
  for(const z of [.22,-.86])rounded(body,side*1.025,1.5,z,.035,.06,.27,trim,.01);
  for(const z of [.16,-.9])rounded(body,side*1.02,1.21,z,.024,.78,.018,trim,.006);
  rounded(body,side*1.11,1.88,1.07,.25,.22,.3,trim,.04);
  rounded(body,side*.8,2.56,-.47,.045,.15,3.15,trim,.018);
  rounded(body,side*1.04,.63,-.12,.19,.1,2.2,alloy,.025);
  for(const z of [-1.5,1.5]){const arch=part(body,new T.TorusGeometry(.61,.095,8,24,Math.PI),trim,side*1.02,.62,z);arch.rotation.y=Math.PI/2;}
 }
 rounded(body,0,1.18,2.37,1.3,.4,.055,trim);
 for(let i=0;i<5;i++)rounded(body,0,1.02+i*.075,2.41,1.23,.018,.024,alloy,.006);
 rounded(body,0,.78,2.4,2.1,.25,.21,trim,.04);rounded(body,0,.76,-2.42,2.1,.28,.22,trim,.04);
 rounded(body,0,.81,2.52,.5,.13,.018,new T.MeshStandardMaterial({color:'#dedcc6'}),.012);
 const running=new T.MeshStandardMaterial({color:'#fff6d7',emissive:'#fff1cc',emissiveIntensity:2.2});
 for(const x of [-.77,.77]){const ring=part(body,new T.TorusGeometry(.17,.028,8,24),running,x,1.36,2.4);part(body,new T.CircleGeometry(.138,24),glass,x,1.36,2.403)}
 const brakeMat=new T.MeshStandardMaterial({color:'#ac1716',emissive:'#ed2420',emissiveIntensity:.4});
 for(const x of [-.85,.85])for(const y of [1.11,1.55])rounded(body,x,y,-2.377,.16,.23,.05,brakeMat,.04);
 const badgeCanvas=document.createElement('canvas');badgeCanvas.width=512;badgeCanvas.height=64;const badgeCtx=badgeCanvas.getContext('2d');badgeCtx.fillStyle='#596d66';badgeCtx.fillRect(0,0,512,64);badgeCtx.fillStyle='#e2e5de';badgeCtx.font='bold 36px Arial';badgeCtx.textAlign='center';badgeCtx.fillText('D E F E N D E R',256,46);const badgeTex=new T.CanvasTexture(badgeCanvas);badgeTex.colorSpace=T.SRGBColorSpace;part(body,new T.PlaneGeometry(1.12,.14),new T.MeshBasicMaterial({map:badgeTex}),0,1.625,2.365);
 const wheels=[];
 function wheel(parent,x,y,z,spare=false){const pivot=new T.Group();pivot.position.set(x,y,z);parent.add(pivot);const spin=new T.Group();pivot.add(spin);
  const tire=part(spin,new T.CylinderGeometry(.55,.55,.29,32),rubber,0,0,0);tire.rotation.z=Math.PI/2;
  const hub=part(spin,new T.CylinderGeometry(.34,.34,.305,24),alloy,0,0,0);hub.rotation.z=Math.PI/2;
  for(const side of [-1,1])for(let i=0;i<5;i++){const a=i*Math.PI*2/5;const spoke=rounded(spin,side*.163,Math.sin(a)*.2,Math.cos(a)*.2,.027,.08,.35,trim,.014);spoke.rotation.x=-a}
  for(let i=0;i<28;i++){const a=i*Math.PI*2/28;const tread=rounded(spin,0,Math.cos(a)*.546,Math.sin(a)*.546,.30,.042,.10,rubber,.008);tread.rotation.x=a}
  if(spare){pivot.rotation.y=Math.PI/2}else wheels.push({pivot,spin,front:z>0});return pivot;
 }
 for(const side of [-1,1])for(const z of [-1.5,1.5])wheel(root,side*1.02,.59,z);
 wheel(body,0,1.53,-2.57,true);
 const headlights=[];for(const x of [-.76,.76]){const light=new T.SpotLight('#fff1d2',0,65,.4,.45,1.4);light.position.set(x,1.33,2.2);light.target.position.set(x,.1,42);root.add(light,light.target);headlights.push(light)}
 return{g:root,wheels,body,brakeMat,headlights,animate(speed,steer,brake,night,dt,time){for(const w of wheels){w.spin.rotation.x+=speed*dt/.55;w.pivot.rotation.y=w.front?steer*.4:0}body.rotation.z=T.MathUtils.lerp(body.rotation.z,-steer*Math.min(Math.abs(speed)/25,1)*.035,dt*5);body.rotation.x=T.MathUtils.lerp(body.rotation.x,brake&&Math.abs(speed)>2?.024:0,dt*5);body.position.y=Math.sin(time*10)*Math.min(Math.abs(speed),20)*.0008;brakeMat.emissiveIntensity=brake?4:night?1.2:.25;headlights.forEach(l=>l.intensity=night?65:0)}};
}

export function createHuman(shirtColor='#ccc7b6',trouserColor='#35434c'){
 const g=new T.Group();g.name='Human character';
 const skin=new T.MeshStandardMaterial({color:'#c99d87',roughness:.68});
 const shirt=new T.MeshStandardMaterial({color:shirtColor,roughness:.95});
 const trousers=new T.MeshStandardMaterial({color:trouserColor,roughness:.94});
 const shoe=new T.MeshStandardMaterial({color:'#292d2c',roughness:.76});
 const torso=part(g,new T.LatheGeometry([new T.Vector2(.17,.91),new T.Vector2(.20,1.04),new T.Vector2(.22,1.28),new T.Vector2(.255,1.42),new T.Vector2(.10,1.49)],24),shirt,0,0,0);torso.scale.z=.65;
 ellipsoid(g,0,.94,0,.205,.16,.13,trousers);
 const headMount=new T.Group();headMount.position.y=1.33;g.add(headMount);
 const fallback=new T.Group();headMount.add(fallback);ellipsoid(fallback,0,.36,0,.112,.15,.115,skin);ellipsoid(fallback,0,.20,0,.065,.1,.065,skin);
 ellipsoid(fallback,0,.405,-.013,.113,.102,.114,new T.MeshStandardMaterial({color:'#302821',roughness:1}));
 const limbs=[];
 for(const side of [-1,1]){
  const leg=new T.Group();leg.position.set(side*.108,.94,0);g.add(leg);
  part(leg,new T.CapsuleGeometry(.094,.26,5,12),trousers,0,-.22,0);
  const knee=new T.Group();knee.position.y=-.43;leg.add(knee);part(knee,new T.CapsuleGeometry(.073,.27,5,12),trousers,0,-.2,0);ellipsoid(knee,0,-.445,.067,.09,.06,.155,shoe);
  const arm=new T.Group();arm.position.set(side*.251,1.405,0);arm.rotation.z=side*.075;g.add(arm);part(arm,new T.CapsuleGeometry(.078,.15,4,12),shirt,0,-.12,0);
  const elbow=new T.Group();elbow.position.y=-.26;arm.add(elbow);part(elbow,new T.CapsuleGeometry(.048,.18,4,12),skin,0,-.13,0);ellipsoid(elbow,0,-.292,.007,.042,.072,.028,skin);
  for(let f=0;f<4;f++)part(elbow,new T.CapsuleGeometry(.007,.041,3,6),skin,(f-1.5)*.016,-.36,.009);
  limbs.push({side,leg,knee,arm,elbow});
 }
 return{g,headMount,fallback,animate(time,speed){const moving=Math.min(Math.abs(speed)/3,1),phase=time*(Math.abs(speed)>5?11:7.5);for(const l of limbs){const swing=Math.sin(phase+(l.side>0?Math.PI:0))*moving;l.leg.rotation.x=swing*.46;l.knee.rotation.x=Math.max(0,-swing)*.63;l.arm.rotation.x=-swing*.36;l.elbow.rotation.x=-.11-Math.max(0,swing)*.16}torso.rotation.z=Math.sin(phase)*moving*.017;headMount.rotation.y=Math.sin(time*.65)*.055;g.position.y=Math.abs(Math.sin(phase))*moving*.025}};
}

export async function loadScannedHeads(humans,isDisposed){
 const loader=new GLTFLoader();const tex=new T.TextureLoader();
 const [gltf,color,normal]=await Promise.all([loader.loadAsync('./human-head.glb'),tex.loadAsync('./human-color.jpg'),tex.loadAsync('./human-normal.jpg')]);
 color.colorSpace=T.SRGBColorSpace;
 let geometry;gltf.scene.traverse(o=>{if(o.isMesh&&!geometry)geometry=o.geometry});
 if(!geometry)throw new Error('Human scan contains no mesh');
 const material=new T.MeshStandardMaterial({map:color,normalMap:normal,normalScale:new T.Vector2(.6,.6),roughness:.65});
 geometry.computeBoundingBox();const bound=geometry.boundingBox,scale=.55/(bound.max.y-bound.min.y);
 if(isDisposed()){geometry.dispose();material.dispose();color.dispose();normal.dispose();return}
 for(const h of humans){const mesh=new T.Mesh(geometry,material);mesh.scale.setScalar(scale);mesh.position.y=-bound.min.y*scale;mesh.castShadow=true;h.headMount.add(mesh);h.fallback.visible=false}
 return[color,normal];
}

export function weatherMaterials(materials){
 for(const [color,m] of materials){if(['#50585a','#b9b4a0','#848866','#cdbb93','#dfc798','#83aaa6','#cfa388','#b6bfab','#dfd6b7','#e7e2cc','#d7cfb6'].includes(color)){
 m.roughness=color==='#50585a'?.84:.95;m.onBeforeCompile=shader=>{shader.vertexShader='varying vec3 efWorld;\n'+shader.vertexShader;shader.vertexShader=shader.vertexShader.replace('#include <worldpos_vertex>','#include <worldpos_vertex>\nefWorld=(modelMatrix*vec4(transformed,1.0)).xyz;');shader.fragmentShader='varying vec3 efWorld;\nfloat efNoise(vec3 p){return fract(sin(dot(p,vec3(12.9898,78.233,37.719)))*43758.5453);}\n'+shader.fragmentShader;shader.fragmentShader=shader.fragmentShader.replace('#include <color_fragment>','#include <color_fragment>\nfloat grain=efNoise(floor(efWorld*48.0)); float stain=efNoise(floor(efWorld*1.3)); diffuseColor.rgb*=mix(0.84,1.08,grain)*mix(0.91,1.04,stain);')};
 }}
}

export function createAtmosphere(scene){
 const uniforms={day:{value:1}};
 const sky=new T.Mesh(new T.SphereGeometry(650,32,16),new T.ShaderMaterial({side:T.BackSide,depthWrite:false,uniforms,vertexShader:'varying vec3 vDir;void main(){vDir=position;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.0);}',fragmentShader:`varying vec3 vDir;uniform float day;
 float hash(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453);}float noise(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);return mix(mix(hash(i),hash(i+vec2(1,0)),f.x),mix(hash(i+vec2(0,1)),hash(i+1.),f.x),f.y);}
 void main(){vec3 d=normalize(vDir);float h=max(d.y,0.);vec3 c=mix(vec3(.83,.81,.73),vec3(.27,.49,.65),pow(h,.45));float n=noise(d.xz/(h+.12)*2.)*.65+noise(d.xz/(h+.12)*5.)*.35;float cloud=smoothstep(.55,.75,n)*smoothstep(.03,.25,h);c=mix(c,vec3(.92,.91,.86),cloud*.8);float sun=pow(max(dot(d,normalize(vec3(-90.,140.,65.))),0.),850.);c+=vec3(1.,.78,.45)*sun*2.;c=mix(vec3(.025,.047,.078)+vec3(.04,.07,.10)*h,c,day);gl_FragColor=vec4(c,1.);}` }));scene.add(sky);
 const faces=[];for(let i=0;i<6;i++){const c=document.createElement('canvas');c.width=c.height=64;const ctx=c.getContext('2d');const grad=ctx.createLinearGradient(0,0,0,64);grad.addColorStop(0,i===3?'#68715e':'#8da6b8');grad.addColorStop(.65,'#d3d3c4');grad.addColorStop(1,'#6a705e');ctx.fillStyle=grad;ctx.fillRect(0,0,64,64);faces.push(c)}
 const env=new T.CubeTexture(faces);env.colorSpace=T.SRGBColorSpace;env.needsUpdate=true;scene.environment=env;scene.environmentIntensity=.8;
 return{setNight(n){uniforms.day.value=n?0:1;scene.environmentIntensity=n?.09:.8},dispose(){env.dispose()}};
}
