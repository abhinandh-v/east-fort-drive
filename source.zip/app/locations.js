import {VILLAGES} from './villages.js';
export const LOCATIONS=[
 {id:'fort',name:'East Fort',lat:8.48275,lon:76.94765},
 {id:'chalai',name:'Chalai Market',lat:8.4821,lon:76.953},
 {id:'station',name:'Thampanoor',lat:8.486,lon:76.952},
 {id:'museum',name:'Napier Museum',lat:8.50884,lon:76.95487},
 {id:'palace',name:'Kanakakkunnu',lat:8.51082,lon:76.95790},
 {id:'kowdiar',name:'Kowdiar',lat:8.521,lon:76.963},
 {id:'pattom',name:'Pattom',lat:8.522,lon:76.944},
 {id:'medical',name:'Medical College',lat:8.52408,lon:76.92715},
 {id:'beach',name:'Shanghumukham approach',lat:8.483,lon:76.911},
 {id:'valiathura',name:'Valiathura',lat:8.461,lon:76.926},
 {id:'lulu',name:'Lulu / NH 66',lat:8.51403,lon:76.89842},
 {id:'thiruvallam',name:'Thiruvallam',lat:8.44,lon:76.954},
 ...VILLAGES
];
export function resolveLocation(id,data,network){const v=LOCATIONS.find(v=>v.id===id);if(!v)return null;const x=v.x??(v.lon-data.origin[1])*111320*Math.cos(data.origin[0]*Math.PI/180),z=v.z??(data.origin[0]-v.lat)*111320;const p=network.nearest(x,z);return p?{...p,name:v.name}:null;}
