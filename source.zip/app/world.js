import * as T from 'three';
import {createGameAudio} from './audio.js';
import {createDefender,createHuman,loadScannedHeads,weatherMaterials,createAtmosphere} from './realism.js';

// Original, deliberately compressed neighborhood: +X east, -Z north.
export function startGame(host,update){
 const scene=new T.Scene(); scene.background=new T.Color('#c6dbe0');scene.fog=new T.Fog('#c6dbe0',170,600);
 let disposed=false,faceStatus='loading';const atmosphere=createAtmosphere(scene),audio=createGameAudio();
 const renderer=new T.WebGLRenderer({antialias:true,powerPreference:'high-performance'});
 renderer.setPixelRatio(Math.min(devicePixelRatio,1.6));renderer.shadowMap.enabled=true;renderer.shadowMap.type=T.PCFSoftShadowMap;renderer.outputColorSpace=T.SRGBColorSpace;renderer.toneMapping=T.ACESFilmicToneMapping;renderer.toneMappingExposure=1.2;host.appendChild(renderer.domElement);
 const camera=new T.PerspectiveCamera(54,1,.15,1000),hemi=new T.HemisphereLight(0xe0f3ff,0x847350,1.35);scene.add(hemi);
 const sun=new T.DirectionalLight(0xffd4a1,3.3);sun.position.set(-90,140,65);sun.castShadow=true;sun.shadow.mapSize.set(2048,2048);Object.assign(sun.shadow.camera,{left:-190,right:190,top:190,bottom:-190,near:1,far:400});sun.shadow.bias=-.0004;scene.add(sun);
 const mats=new Map(),geo=new T.BoxGeometry(1,1,1),colliders=[],buildings=[],textures=[];
 const mat=(c)=>{if(!mats.has(c))mats.set(c,new T.MeshStandardMaterial({color:c,roughness:.83}));return mats.get(c)};
 function box(x,y,z,w,h,d,c,parent=scene){const m=new T.Mesh(geo,mat(c));m.position.set(x,y,z);m.scale.set(w,h,d);m.castShadow=h>1;m.receiveShadow=true;parent.add(m);return m}
 function solid(x,z,w,h,d,c){box(x,h/2,z,w,h,d,c);colliders.push({x,z,w:w/2,d:d/2});buildings.push({x,z,w,d})}
 function label(text,x,y,z,w=12,bg='#173c46',rot=0){const c=document.createElement('canvas');c.width=512;c.height=96;const a=c.getContext('2d');a.fillStyle=bg;a.fillRect(0,0,512,96);a.fillStyle='#fff2cd';a.textAlign='center';a.textBaseline='middle';a.font='bold 33px Arial';a.fillText(text,256,50,486);const tex=new T.CanvasTexture(c);tex.colorSpace=T.SRGBColorSpace;textures.push(tex);const p=new T.Mesh(new T.PlaneGeometry(w,w*96/512),new T.MeshBasicMaterial({map:tex,side:T.DoubleSide}));p.position.set(x,y,z);p.rotation.y=rot;scene.add(p);return p}
 box(0,-.4,0,760,.6,760,'#848866');
 const roads=[{x:0,z:0,w:600,d:22},{x:30,z:0,w:28,d:590},{x:-252,z:0,w:17,d:560},{x:238,z:0,w:19,d:560},{x:0,z:-148,w:600,d:17},{x:0,z:154,w:600,d:20}];
 for(const r of roads){box(r.x,.01,r.z,r.w,.12,r.d,'#50585a');if(r.w>r.d){box(r.x,.1,r.z-r.d/2-1,r.w,.2,2,'#b9b4a0');box(r.x,.1,r.z+r.d/2+1,r.w,.2,2,'#b9b4a0');for(let x=-290;x<295;x+=15)box(x,.09,r.z,.28,.03,0.1,'#ece1b6').scale.set(6,.03,.3)}else{for(let z=-285;z<285;z+=15)box(r.x,.1,z,.35,.03,6,'#ece1b6')}}
 for(let i=0;i<8;i++){box(12+i*2.5,.15,-22,1.3,.04,7,'#ddd9bb');box(12+i*2.5,.15,24,1.3,.04,7,'#ddd9bb')}
 // Temple frontage and layered gopuram, kept exterior-only.
 solid(-221,0,30,8,116,'#b39a72');colliders.push({x:-201,z:0,w:10,d:16});
 for(let level=0;level<7;level++){const width=30-level*3.1,depth=18-level*1.3,y=9+level*4.5;box(-201,y,0,depth,4.1,width,'#d6b980');box(-201,y+2.2,0,depth+1.3,.7,width+1.2,'#e9cd98');for(let k=0;k<Math.floor(width/3);k++){const z=-width/2+1.5+k*3;box(-201+depth/2+.25,y,z,.6,2,1.2,'#b89a63');box(-201+depth/2+.7,y+1.3,z,1,.4,1.6,'#f0d5a0')}}
 for(let i=-2;i<=2;i++){const m=new T.Mesh(new T.SphereGeometry(.8,8,6),mat('#e7bf62'));m.position.set(-201,41,i*2.1);scene.add(m)}
 box(-190,4,0,.3,8,7,'#392e26');label('SREE PADMANABHASWAMY',-180,8,0,29,'#79613b',Math.PI/2);
 // Padmatheertham tank with stepped perimeter north of the approach.
 solid(-143,-64,74,.4,66,'#468e89');
 for(let i=0;i<4;i++){const w=78+i*3,d=70+i*3;box(-143,.3+i*.19,-64-d/2,w,.4,1.8,'#aaa38a');box(-143,.3+i*.19,-64+d/2,w,.4,1.8,'#aaa38a');box(-143-w/2,.3+i*.19,-64,1.8,.4,d,'#aaa38a');box(-143+w/2,.3+i*.19,-64,1.8,.4,d,'#aaa38a')}
 label('PADMATHEERTHAM',-142,3,-22,20);
 // East Fort gateway, with a genuinely traversable opening along the approach.
 for(const z of [-18,18]){solid(-40,z,8,10,17,'#e7e2cc');box(-40,10.6,z,10,1,19,'#f9f0d7');box(-40,12,z,7,2,14,'#d6d1ba')}
 box(-40,10.8,0,8,3.2,24,'#f3ead5');box(-40,12.8,0,10,.8,27,'#fff2da');label('EAST FORT',-35.8,10.8,0,17,'#7a745f',Math.PI/2);
 for(const z of [-83,83])solid(-40,z,3,4,108,'#d7cfb6');
 // Palace roofs, street shops and market awnings.
 function roof(x,z,w,d,y){const r=new T.Mesh(new T.ConeGeometry(1,1,4),mat('#98563a'));r.position.set(x,y,z);r.rotation.y=Math.PI/4;r.scale.set(w*.72,4,d*.72);r.castShadow=true;scene.add(r)}
 solid(-149,67,67,6,52,'#d4ba8f');
 roof(-149,67,73,58,8);label('KUTHIRAMALIKA',-147,5,39,25,'#684630');
 const names=['CHALAI STORES','KERALA SPICES','TEXTILES','BAKERY & TEA','FRESH FRUIT','SILKS','MALABAR TRADERS','FLOWER MARKET','BOOK HOUSE','COFFEE'];
 const colors=['#cdbb93','#dfc798','#83aaa6','#cfa388','#b6bfab','#dfd6b7'];let seed=417;
 const rand=()=>{seed=(seed*1664525+1013904223)>>>0;return seed/4294967296};
 function shop(x,z,w,d,h,index,face=1){solid(x,z,w,h,d,colors[index%colors.length]);box(x,h+.3,z,w+1,.6,d+1,'#c1b49d');const front=z+face*(d/2+.1);for(let a=-w/2+2;a<w/2-1;a+=4){box(x+a,1.7,front,2.9,3.2,.2,'#4c645f');if(h>7)box(x+a,6,front,1.8,2,.2,'#3b6065')}label(names[index%names.length],x,4.2,front+face*.2,w*.93,index%2?'#9d4931':'#1e6066');const awning=box(x,3.25,front+face*1.3,w+.6,.25,3,index%2?'#d3984e':'#417e79');awning.rotation.x=face*.12;for(let a=-w/2+1;a<w/2;a+=3){box(x+a,.5,front+face*2,2,.8,1.1,index%2?'#b18043':'#a5a347')}if(index%3===0){box(x,h+1,z,2,1.5,2,'#4e5450');box(x+3,h+.7,z,3,.6,2,'#8d9992')}}
 let idx=0;
 for(let x=67;x<282;x+=19){if(Math.abs(x-238)<20)continue;shop(x,-25,17,24,7+rand()*8,idx++,1);shop(x,29,17,26,6+rand()*9,idx++,-1)}
 for(let x=-176;x< -67;x+=21)shop(x,23,19,15,6+rand()*4,idx++,-1);
 for(const z of [-185,-110,105,194])for(let x=-280;x<295;x+=24){if(Math.abs(x-30)<29||Math.abs(x+252)<25||Math.abs(x-238)<24||Math.abs(x+40)<13)continue;if(z===-110&&x>-225&&x<-85)continue;shop(x,z,20,22,7+rand()*13,idx++,z<0?1:-1)}
 for(const x of [-285,267])for(let z=-250;z<270;z+=28){if(Math.abs(z)<48||Math.abs(z+148)<27||Math.abs(z-154)<28)continue;solid(x,z,20,6+rand()*16,22,colors[idx++%6]);}
 // Gandhi Park and open maidan beside the bus interchange.
 box(83,0.2,80,59,.25,58,'#6c8b58');box(152,.13,99,66,.2,55,'#b49a70');
 label('GANDHI PARK',83,4,48,18);label('PUTHARIKANDAM MAIDAN',152,3.5,69,29);
 function palm(x,z,h=13){const trunk=new T.Mesh(new T.CylinderGeometry(.19,.37,h,12),mat('#847358'));trunk.position.set(x,h/2,z);scene.add(trunk);const verts=[];for(let j=0;j<9;j++){const a=j*Math.PI*2/9;for(let i=0;i<18;i++){const t=i/18,t2=(i+1)/18,len=5.3;const p=new T.Vector3(Math.sin(a)*t*len,h+Math.sin(t*Math.PI)*1.0-t*t*2,Math.cos(a)*t*len),q=new T.Vector3(Math.sin(a)*t2*len,h+Math.sin(t2*Math.PI)*1.0-t2*t2*2,Math.cos(a)*t2*len);for(const side of [-1,1]){const width=Math.sin(t*Math.PI)*.8+.08;const tip=p.clone().add(new T.Vector3(Math.cos(a)*side*width,-.28, -Math.sin(a)*side*width));verts.push(...p.toArray(),...q.toArray(),...tip.toArray())}}}const geom=new T.BufferGeometry();geom.setAttribute('position',new T.Float32BufferAttribute(verts,3));geom.computeVertexNormals();const foliage=new T.Mesh(geom,new T.MeshStandardMaterial({color:'#3f7045',roughness:1,side:T.DoubleSide}));foliage.position.set(x,0,z);foliage.castShadow=true;scene.add(foliage)}
 for(let i=0;i<42;i++){const x=-280+rand()*560,z=-260+rand()*520;if(roads.some(r=>Math.abs(x-r.x)<r.w/2+4&&Math.abs(z-r.z)<r.d/2+4))continue;if(colliders.some(c=>Math.abs(x-c.x)<c.w+2&&Math.abs(z-c.z)<c.d+2))continue;palm(x,z,10+rand()*5)}
 for(const x of [59,105])for(const z of [59,98]){palm(x,z);box(x,1,z+4,5,.4,1,'#634c32');box(x,1.7,z+4.5,5,1,.2,'#634c32')}
 const lamps=[];for(let z=-240;z<265;z+=42){for(const x of [12,48]){box(x,5,z,.2,10,.2,'#4b5b56');box(x+1.1,10,z,2.5,.17,.2,'#4b5b56');const lamp=box(x+2.2,9.9,z,1,.15,.65,'#fff2b7');lamps.push(lamp)}}
 label('EAST FORT BUS STAND',48,5,-65,22,'#315e61',Math.PI/2);
 const vehicles=[];
 function car(x,z,color='#e2ae52',kind='car',angle=0){const g=new T.Group(),bus=kind==='bus',auto=kind==='auto',w=bus?3:auto?1.8:2.2,l=bus?9:auto?3:4.6;box(0,1,0,w,1.25,l,color,g);box(0,bus?2.35:1.85,bus?0:.2,w*.91,bus?1.6:.85,l*.62,auto?'#262f2c':color,g);box(0,bus?2.6:1.94,l*.32+.02,w*.84,.65,.07,'#345c67',g);box(0,bus?2.6:1.94,-l*.32-.02,w*.84,.6,.07,'#345c67',g);for(const side of [-1,1]){box(side*w*.46,bus?2.6:1.95,0,.05,.62,l*.49,'#365b62',g);for(const zz of [-l*.31,l*.31]){const wheel=new T.Mesh(new T.CylinderGeometry(.5,.5,.3,10),mat('#222b2d'));wheel.rotation.z=Math.PI/2;wheel.position.set(side*w*.49,.55,zz);g.add(wheel)}box(side*w*.32,1.15,l/2+.02,.42,.25,.08,'#fff1bb',g);box(side*w*.32,1.15,-l/2-.02,.4,.2,.08,'#b34a36',g)}if(bus){box(0,1.2,0,w+.03,.23,l+.03,'#eedeb7',g);box(0,3.2,0,w+.1,.2,l+.1,'#eee1c4',g)}g.position.set(x,0,z);g.rotation.y=angle;scene.add(g);const v={g,x,z,angle,speed:0,r:bus?4.7:2.3};vehicles.push(v);return v}
 const defender=createDefender();defender.g.position.set(3,0,1);defender.g.rotation.y=-Math.PI/2;scene.add(defender.g);const playerCar={g:defender.g,x:3,z:1,angle:-Math.PI/2,speed:0,r:2.65};vehicles.push(playerCar);car(51,-85,'#b84e3d','bus');car(51,-103,'#426d79','bus');car(62,47,'#d0a53c','auto',Math.PI/2);car(190,13,'#d9d8c7','car',Math.PI/2);car(-95,12,'#5a8b8b','car',Math.PI/2);
 const traffic=[car(23,-225,'#d2ab41','auto'),car(38,230,'#b84f3e','bus',Math.PI),car(23,110,'#c8d4c8'),car(38,-65,'#659494','car',Math.PI)];
 const human=createHuman(),walker=human.g;scene.add(walker);walker.visible=false;
 const people=[];for(let i=0;i<12;i++){const person=createHuman(['#b6b1a1','#587f82','#c6b496','#9aada5'][i%4],i%3?'#35434c':'#b7b3a9');const g=person.g;g.position.set(68+rand()*200,0,i%2?-12:15);scene.add(g);people.push({...person,home:g.position.x,phase:rand()*6})}
 if(typeof window.Image!=='undefined')loadScannedHeads([human,...people],()=>disposed).then(ts=>{if(ts){textures.push(...ts);faceStatus='scanned'}}).catch(e=>{faceStatus='fallback';console.warn('Scanned face unavailable; using the built-in character.',e)});
 weatherMaterials(mats);
 const streetLights=[];for(let z=-210;z<220;z+=84){const l=new T.PointLight('#ffdba3',0,25,2);l.position.set(14,9,z);scene.add(l);streetLights.push(l)}
 const rainGeometry=new T.BufferGeometry(),rainPositions=new Float32Array(1200*6);for(let i=0;i<1200;i++){const k=i*6;rainPositions[k]=(rand()-.5)*85;rainPositions[k+1]=rand()*35;rainPositions[k+2]=(rand()-.5)*85;rainPositions[k+3]=rainPositions[k]-.05;rainPositions[k+4]=rainPositions[k+1]-.7;rainPositions[k+5]=rainPositions[k+2]}
 rainGeometry.setAttribute('position',new T.BufferAttribute(rainPositions,3));const rain=new T.LineSegments(rainGeometry,new T.LineBasicMaterial({color:'#c2d7df',transparent:true,opacity:.38,depthWrite:false}));scene.add(rain);rain.visible=false;
 const marker=new T.Mesh(new T.TorusGeometry(5,.25,8,40),new T.MeshBasicMaterial({color:'#ffc56c'}));marker.rotation.x=Math.PI/2;marker.position.y=.45;scene.add(marker);marker.visible=false;
 const beam=new T.Mesh(new T.CylinderGeometry(.65,.65,24,12),new T.MeshBasicMaterial({color:'#ffcf7b',transparent:true,opacity:.25,depthWrite:false}));scene.add(beam);beam.visible=false;
 const stops=[{x:144,z:2,name:'Chalai market'},{x:-107,z:0,name:'Temple approach'},{x:30,z:-84,name:'East Fort bus stand'}];
 const state={x:3,z:1,angle:-Math.PI/2,speed:0,mode:'Driving',place:'East Fort',mission:'Explore the neighborhood',step:0,active:false,paused:false,night:false,rain:false,cam:0};let currentCar=playerCar;
 const keys={};let frame=0,last=performance.now(),hudTime=0,elapsed=0,stopHold=0,noticeUntil=0;
 function blocked(x,z,r){return Math.abs(x)>298||Math.abs(z)>282||colliders.some(c=>Math.abs(x-c.x)<c.w+r&&Math.abs(z-c.z)<c.d+r)}
 function pushHud(){update({speed:Math.round(Math.abs(state.speed)*3.6),mode:state.mode,place:state.place,mission:state.mission,step:state.step,active:state.active,paused:state.paused,night:state.night,rain:state.rain,sound:audio.getStatus().enabled,soundStatus:audio.getStatus().status})}
 function action(a){const priorMode=state.mode;if(document.activeElement?.tagName==='BUTTON')document.activeElement.blur();if(a==='pause'){state.paused=!state.paused;if(state.paused)audio.silence()}
 if(a==='sound')audio.toggle();
 if(a==='horn'&&!state.paused&&state.mode==='Driving')audio.effect('horn');
 if(a==='camera')state.cam=(state.cam+1)%3;
 if(a==='night'){state.night=!state.night;atmosphere.setNight(state.night);scene.background.set(state.night?'#152739':'#c6dbe0');scene.fog.color.copy(scene.background);hemi.intensity=state.night?.3:1.35;sun.intensity=state.night?.25:3.3;sun.color.set(state.night?'#a1c5f2':'#ffd4a1');streetLights.forEach(l=>l.intensity=state.night?55:0);lamps.forEach(l=>{l.material.emissive.set(state.night?'#ffd791':'#000000');l.material.emissiveIntensity=state.night?2:0})}
 if(a==='rain'){state.rain=!state.rain;rain.visible=state.rain;mat('#50585a').roughness=state.rain?.22:.84;scene.fog.far=state.rain?330:600;sun.intensity=state.night?.25:state.rain?1.3:3.3}
 if(a==='reset'){state.x=3;state.z=1;state.angle=-Math.PI/2;state.speed=0;if(state.mode==='Driving'){currentCar.x=3;currentCar.z=1}}
 if(a==='enter'&&!state.paused){if(state.mode==='Driving'){const options=[{x:state.x+Math.cos(state.angle)*3.7,z:state.z-Math.sin(state.angle)*3.7},{x:state.x-Math.cos(state.angle)*3.7,z:state.z+Math.sin(state.angle)*3.7}];const p=options.find(p=>!blocked(p.x,p.z,.4));if(p){state.mode='Walking';state.x=p.x;state.z=p.z;state.speed=0;walker.visible=true}}else{const c=vehicles.filter(v=>!traffic.includes(v)).find(v=>Math.hypot(v.x-state.x,v.z-state.z)<6);if(c){currentCar=c;state.mode='Driving';state.x=c.x;state.z=c.z;state.angle=c.angle;state.speed=0;walker.visible=false}}}
 if(a==='mission'){state.active=!state.active;state.step=0;stopHold=0;state.mission='Deliver to Chalai market'}if(priorMode!==state.mode)audio.effect('door');pushHud()}
 function down(e){if(e.target instanceof HTMLElement&&/INPUT|TEXTAREA/.test(e.target.tagName))return;const k=e.key.toLowerCase();if(['w','a','s','d','arrowup','arrowdown','arrowleft','arrowright',' ','f','c','r','h','m','escape'].includes(k))e.preventDefault();keys[k]=true;if(!e.repeat){const acts={f:'enter',c:'camera',r:'reset',h:'horn',m:'sound',escape:'pause'};if(acts[k])action(acts[k])}}
 function up(e){keys[e.key.toLowerCase()]=false}function blur(){Object.keys(keys).forEach(k=>keys[k]=false);state.paused=true;audio.silence();pushHud()}
 window.addEventListener('keydown',down);window.addEventListener('keyup',up);window.addEventListener('blur',blur);
 const resize=()=>{renderer.setSize(host.clientWidth,host.clientHeight);camera.aspect=host.clientWidth/host.clientHeight;camera.updateProjectionMatrix()};window.addEventListener('resize',resize);resize();camera.position.set(33,17,12);
 const map=document.getElementById('minimap'),ctx=map?.getContext('2d');
 function drawMap(){if(!ctx)return;ctx.fillStyle='#17353d';ctx.fillRect(0,0,240,200);const sx=x=>120+x*.35,sz=z=>100+z*.30;ctx.fillStyle='#3d5456';for(const b of buildings)ctx.fillRect(sx(b.x-b.w/2),sz(b.z-b.d/2),b.w*.35,b.d*.30);ctx.fillStyle='#819191';for(const r of roads)ctx.fillRect(sx(r.x-r.w/2),sz(r.z-r.d/2),r.w*.35,r.d*.30);ctx.fillStyle='#3c9d9b';ctx.fillRect(sx(-180),sz(-97),74*.35,66*.30);ctx.font='10px Arial';ctx.fillStyle='#c5d4cd';ctx.fillText('TEMPLE',17,91);ctx.fillText('CHALAI',170,91);if(state.active){const s=stops[state.step];ctx.fillStyle='#ffc66f';ctx.beginPath();ctx.arc(sx(s.x),sz(s.z),5,0,Math.PI*2);ctx.fill()}ctx.save();ctx.translate(sx(state.x),sz(state.z));ctx.rotate(-state.angle);ctx.fillStyle='#fff0c2';ctx.beginPath();ctx.moveTo(0,6);ctx.lineTo(-4,-4);ctx.lineTo(4,-4);ctx.closePath();ctx.fill();ctx.restore()}
 const desired=new T.Vector3(),target=new T.Vector3();
 function tick(now){frame=requestAnimationFrame(tick);const dt=Math.min((now-last)/1000,.045);last=now;if(!state.paused){elapsed+=dt;const forward=(keys.w||keys.arrowup?1:0)-(keys.s||keys.arrowdown?1:0),steer=(keys.a||keys.arrowleft?1:0)-(keys.d||keys.arrowright?1:0);if(state.mode==='Driving'){state.speed+=forward*13*dt;state.speed*=Math.exp(-(keys[' ']?6:forward?.22:1.4)*dt);state.speed=T.MathUtils.clamp(state.speed,-10,27);state.angle+=steer*1.45*dt*Math.min(Math.abs(state.speed)/5,1)*Math.sign(state.speed)}else{state.speed=forward*(keys.shift?7:4);state.angle+=steer*2.4*dt}
 const nx=state.x+Math.sin(state.angle)*state.speed*dt,nz=state.z+Math.cos(state.angle)*state.speed*dt,r=state.mode==='Driving'?1.7:.4;
 const hitVehicle=vehicles.some(v=>(v!==currentCar||state.mode==='Walking')&&Math.hypot(nx-v.x,nz-v.z)<v.r+r*.45);
 if(!blocked(nx,nz,r)&&!hitVehicle){state.x=nx;state.z=nz}else{if(state.mode==='Driving'&&Math.abs(state.speed)>2.5)audio.effect('impact',Math.min(1,Math.abs(state.speed)/15));state.speed*= -.18;}
 if(state.mode==='Driving'){currentCar.x=state.x;currentCar.z=state.z;currentCar.angle=state.angle;currentCar.g.position.set(state.x,0,state.z);currentCar.g.rotation.y=state.angle}else{walker.position.set(state.x,0,state.z);walker.rotation.y=state.angle}
 for(let i=0;i<traffic.length;i++){const v=traffic[i],dir=i%2?-1:1;const proposed=v.z+dir*7*dt;const tooClose=vehicles.some(other=>other!==v&&Math.abs(other.x-v.x)<4&&dir*(other.z-v.z)>0&&dir*(other.z-v.z)<13);if(!tooClose&&Math.hypot(v.x-state.x,proposed-state.z)>9)v.z=proposed;if(v.z>270)v.z=-270;if(v.z< -270)v.z=270;v.g.position.z=v.z}
 human.animate(elapsed,state.mode==='Walking'?state.speed:0);defender.animate(state.mode==='Driving'&&currentCar===playerCar?state.speed:0,steer,!!keys[' '],state.night,dt,elapsed);
 for(const p of people){p.g.position.x=p.home+Math.sin(elapsed*.2+p.phase)*4;p.g.rotation.y=Math.cos(elapsed*.2+p.phase)>0?Math.PI/2:-Math.PI/2;p.animate(elapsed+p.phase,1.8)}
 if(state.rain){rain.position.set(state.x,0,state.z);for(let i=0;i<1200;i++){const k=i*6;rainPositions[k+1]-=dt*19;if(rainPositions[k+1]<0)rainPositions[k+1]=35;rainPositions[k+4]=rainPositions[k+1]-.7}rainGeometry.attributes.position.needsUpdate=true;}
 if(state.active){const s=stops[state.step];state.mission='Deliver to '+s.name;marker.visible=beam.visible=true;marker.position.set(s.x,.5,s.z);beam.position.set(s.x,12,s.z);marker.scale.setScalar(1+Math.sin(elapsed*3)*.08);if(Math.hypot(state.x-s.x,state.z-s.z)<7&&Math.abs(state.speed)<2)stopHold+=dt;else stopHold=0;if(stopHold>1.2){stopHold=0;if(state.step<2)state.step++;else{state.active=false;noticeUntil=elapsed+8;state.place='Delivery complete!'}}}else marker.visible=beam.visible=false;
 if(elapsed>noticeUntil)state.place=state.x>67?'Chalai Market':state.x< -85?'Temple Approach':state.z< -40?'East Fort Bus Stand':'East Fort';
 }
 audio.tick({...state,throttle:!!(keys.w||keys.arrowup),braking:!!keys[' ']},dt,Math.max(...traffic.map(v=>Math.max(0,1-Math.hypot(state.x-v.x,state.z-v.z)/55))));
 const dist=state.mode==='Driving'?10:3.8,camDist=state.cam===1?dist*1.8:dist;desired.set(state.x-Math.sin(state.angle)*camDist,state.cam===2?state.mode==='Walking'?1.65:65:state.cam===1?15:state.mode==='Driving'?4.8:2.15,state.z-Math.cos(state.angle)*camDist);if(state.cam===2&&state.mode==='Walking'){desired.set(state.x+Math.sin(state.angle)*3,1.68,state.z+Math.cos(state.angle)*3)}camera.position.lerp(desired,1-Math.exp(-4*dt));target.set(state.x+Math.sin(state.angle)*(state.cam===2&&state.mode==='Walking'?0:3),state.mode==='Driving'?1.5:1.25,state.z+Math.cos(state.angle)*(state.cam===2&&state.mode==='Walking'?0:3));camera.lookAt(target);renderer.render(scene,camera);hudTime+=dt;if(hudTime>.12){hudTime=0;pushHud();drawMap()}}
 frame=requestAnimationFrame(tick);pushHud();
 const lifecycle=new AbortController();const context=document.modelContext;if(context?.registerTool){try{Promise.resolve(context.registerTool({name:'set_game_paused',description:'Pause or resume the East Fort game and return the active edition, face loading and audio status.',inputSchema:{type:'object',properties:{paused:{type:'boolean'}},required:['paused'],additionalProperties:false},annotations:{readOnlyHint:false},execute(input){if(!input||typeof input.paused!=='boolean')throw new Error('paused must be a boolean');state.paused=input.paused;if(state.paused)audio.silence();pushHud();return{paused:state.paused,edition:'Defender Audio',humanFace:faceStatus,audio:audio.getStatus()}}},{signal:lifecycle.signal})).catch(()=>{})}catch{}}
 return{action,key(k,on){keys[k]=on},dispose(){disposed=true;audio.dispose();cancelAnimationFrame(frame);lifecycle.abort();window.removeEventListener('keydown',down);window.removeEventListener('keyup',up);window.removeEventListener('blur',blur);window.removeEventListener('resize',resize);const geometries=new Set(),materials=new Set();scene.traverse(o=>{if(o.geometry)geometries.add(o.geometry);if(o.material)materials.add(o.material)});geometries.forEach(g=>g.dispose());materials.forEach(m=>{if(m.map&&!textures.includes(m.map))m.map.dispose();m.dispose()});textures.forEach(t=>t.dispose());atmosphere.dispose();renderer.dispose();renderer.domElement.remove()}};
}
