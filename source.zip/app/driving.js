const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const approach=(v,target,rate,dt)=>v+(target-v)*(1-Math.exp(-rate*dt));
export function createDrivingDynamics(){let steering=0,yaw=0;return{reset(){steering=yaw=0;},step(state,input,dt){
 dt=clamp(dt,0,.05);const oldSpeed=state.speed,speed=Math.abs(oldSpeed),grip=(input.onRoad?1:.58)*(state.rain?.72:1),turnLimit=.53/(1+speed*.047);
 // Steering winds on progressively, recentres faster, and reduces lock at speed.
 steering=approach(steering,input.steer*turnLimit,input.steer?5.4:8.5,dt);
 const command=input.forward,opposing=command&&Math.sign(command)!==Math.sign(oldSpeed)&&speed>.15;
 const serviceBrake=opposing?9.8*grip:0,handBrake=input.handbrake?12*grip:0;
 let acceleration=0;
 if(serviceBrake||handBrake){const next=Math.max(0,speed-Math.max(serviceBrake,handBrake)*dt);state.speed=Math.sign(oldSpeed)*next;}
 else{const engine=command*(speed<16?7.8:4.5)*(input.onRoad?1:.65);const drag=speed>.01?Math.sign(oldSpeed)*(.16+.0019*speed*speed):0;acceleration=engine-drag;state.speed=oldSpeed+acceleration*dt;if(!command&&Math.sign(state.speed)!==Math.sign(oldSpeed))state.speed=0;}
 const top=input.onRoad?(state.condition<20?18:48):15;state.speed=state.condition<=0?0:clamp(state.speed,-7,top);
 const idealYaw=state.speed*Math.tan(steering)/3.0,availableGrip=grip*(input.handbrake?.65:1),maxYaw=8.4*availableGrip/Math.max(Math.abs(state.speed),2);
 yaw=approach(yaw,clamp(idealYaw,-maxYaw,maxYaw),input.onRoad?8:5,dt);if(Math.abs(state.speed)<.02)yaw=0;state.angle+=yaw*dt;
 return{steering,steerRatio:steering/.53,yawRate:yaw,longitudinal:(state.speed-oldSpeed)/Math.max(dt,.0001),lateral:state.speed*yaw,braking:!!(serviceBrake||handBrake),onRoad:input.onRoad};
 }};}
export function createSuspension(){const springs=Array.from({length:7},()=>({p:0,v:0}));
 function spring(i,target,dt,frequency,damping){const s=springs[i],steps=Math.max(1,Math.ceil(dt/.008)),h=dt/steps;for(let j=0;j<steps;j++){s.v+=((target-s.p)*frequency*frequency-2*damping*frequency*s.v)*h;s.p+=s.v*h;}return s.p;}
 return{reset(){springs.forEach(s=>{s.p=s.v=0;});},step({x,z,angle,speed,longitudinal=0,lateral=0,onRoad=true},dt){
 const wheels=[];for(let i=0;i<4;i++){const side=i<2?-1:1,front=i%2===1,localX=side*1.02,localZ=front?1.5:-1.5,wx=x+Math.cos(angle)*localX+Math.sin(angle)*localZ,wz=z-Math.sin(angle)*localX+Math.cos(angle)*localZ;
 const height=(Math.sin(wx*.72+wz*.31)*.55+Math.sin(wx*1.63-wz*.9)*.3+Math.sin(wz*3.1)*.15)*(onRoad?.018:.105);
 wheels.push(spring(i,height,dt,27,.83));}
 const heave=spring(4,wheels.reduce((a,b)=>a+b,0)/4,dt,11,.78),pitch=spring(5,clamp(-longitudinal*.0045,-.055,.055)+(wheels[0]+wheels[2]-wheels[1]-wheels[3])/6,dt,9,.82),roll=spring(6,clamp(lateral*.006,-.065,.065)+(wheels[2]+wheels[3]-wheels[0]-wheels[1])/4,dt,10,.86);
 return{wheels,heave,pitch,roll};
 }};
}
