import * as T from 'three';
import {createBuildingClearance} from './building-clearance.js';

export function pointInPolygon(x,z,p){let inside=false;for(let i=0,j=p.length-2;i<p.length;j=i,i+=2){const ax=p[i],az=p[i+1],bx=p[j],bz=p[j+1];if((az>z)!==(bz>z)&&x<(bx-ax)*(z-az)/(bz-az)+ax)inside=!inside;}return inside;}
export function nearestSegment(x,z,a,b){const dx=b[0]-a[0],dz=b[1]-a[1],t=Math.max(0,Math.min(1,((x-a[0])*dx+(z-a[1])*dz)/(dx*dx+dz*dz||1)));const px=a[0]+t*dx,pz=a[1]+t*dz;return{x:px,z:pz,t,d:Math.hypot(x-px,z-pz),angle:Math.atan2(dx,dz)};}
class Heap{a=[];push(v){let i=this.a.length;this.a.push(v);while(i){const p=(i-1)>>1;if(this.a[p][0]<=v[0])break;this.a[i]=this.a[p];i=p;}this.a[i]=v;}pop(){const top=this.a[0],v=this.a.pop();if(this.a.length){let i=0;while(i*2+1<this.a.length){let j=i*2+1;if(j+1<this.a.length&&this.a[j+1][0]<this.a[j][0])j++;if(this.a[j][0]>=v[0])break;this.a[i]=this.a[j];i=j;}this.a[i]=v;}return top;}}
export function createRoadNetwork(data){
 const graph=Array.from({length:data.nodes.length},()=>[]),segments=new Map();
 data.roads.forEach((r,ri)=>{for(let i=1;i<r.p.length;i++){const a=r.p[i-1],b=r.p[i],pa=data.nodes[a],pb=data.nodes[b],d=Math.hypot(pa[0]-pb[0],pa[1]-pb[1]);if(!d)continue;graph[a].push([b,d]);graph[b].push([a,d]);for(let x=Math.floor(Math.min(pa[0],pb[0])/250);x<=Math.floor(Math.max(pa[0],pb[0])/250);x++)for(let z=Math.floor(Math.min(pa[1],pb[1])/250);z<=Math.floor(Math.max(pa[1],pb[1])/250);z++){const key=x+','+z;if(!segments.has(key))segments.set(key,[]);segments.get(key).push([ri,i]);}}});
 // Keep routing on the connected component containing East Fort.
 let origin=0;for(let i=1;i<data.nodes.length;i++)if(Math.hypot(...data.nodes[i])<Math.hypot(...data.nodes[origin]))origin=i;
 const connected=new Set([origin]),queue=[origin];for(let i=0;i<queue.length;i++)for(const [n] of graph[queue[i]])if(!connected.has(n)){connected.add(n);queue.push(n);}
 function nearest(x,z,highway=false){let best=null;for(let radius=1;radius<=16&&!best;radius*=2){const seen=new Set();for(let cx=Math.floor(x/250)-radius;cx<=Math.floor(x/250)+radius;cx++)for(let cz=Math.floor(z/250)-radius;cz<=Math.floor(z/250)+radius;cz++)for(const [ri,i] of segments.get(cx+','+cz)||[]){const key=ri+':'+i;if(seen.has(key))continue;seen.add(key);const r=data.roads[ri];if(highway&&!r.highway||!connected.has(r.p[i]))continue;const p=nearestSegment(x,z,data.nodes[r.p[i-1]],data.nodes[r.p[i]]);if(!best||p.d<best.d)best={...p,road:r,ri,i,node:p.t<.5?r.p[i-1]:r.p[i]};}}return best;}
 function route(start,end){const a=nearest(start.x,start.z)?.node,b=end.node??nearest(end.x,end.z)?.node;if(a==null||b==null)return null;const g=new Map([[a,0]]),from=new Map(),heap=new Heap(),goal=data.nodes[b];heap.push([0,a]);while(heap.a.length){const [,v]=heap.pop();if(v===b){const path=[v];while(from.has(path[0]))path.unshift(from.get(path[0]));return {points:path.map(i=>data.nodes[i]),length:g.get(b)};}for(const [n,d]of graph[v]){const cost=g.get(v)+d;if(cost<(g.get(n)??Infinity)){g.set(n,cost);from.set(n,v);const p=data.nodes[n];heap.push([cost+Math.hypot(p[0]-goal[0],p[1]-goal[1]),n]);}}}return null;}
 return{nearest,route,connected,graph};
}

// Test against every road, including crossing roads and the other carriageway.
export function createRoadClearance(data,padding=6){
 const cells=new Map(),size=100;
 for(const road of data.roads)for(let i=1;i<road.p.length;i++){const a=data.nodes[road.p[i-1]],b=data.nodes[road.p[i]],r=road.w/2+padding;
 for(let x=Math.floor((Math.min(a[0],b[0])-r)/size);x<=Math.floor((Math.max(a[0],b[0])+r)/size);x++)for(let z=Math.floor((Math.min(a[1],b[1])-r)/size);z<=Math.floor((Math.max(a[1],b[1])+r)/size);z++){const key=x+','+z;if(!cells.has(key))cells.set(key,[]);cells.get(key).push({a,b,r});}}
 return(x,z)=>!(cells.get(Math.floor(x/size)+','+Math.floor(z/size))||[]).some(s=>nearestSegment(x,z,s.a,s.b).d<=s.r);
}
export function createRegion(scene,data){
 const treeClear=createRoadClearance(data),footprintClear=createBuildingClearance(data),safeBuildings=new Map();let removedBuildings=0;
 function buildings(key){if(!safeBuildings.has(key)){const [cx,cz]=key.split(',').map(Number),ox=cx*data.size,oz=cz*data.size;safeBuildings.set(key,(data.chunks[key]?.b||[]).filter(b=>{const poly=[];for(let i=2;i<b.length;i+=2)poly.push([b[i]+ox,b[i+1]+oz]);const safe=footprintClear(poly);if(!safe)removedBuildings++;return safe;}));}return safeBuildings.get(key);}
 const size=data.size,loaded=new Map(),box=new T.BoxGeometry(1,1,1),dummy=new T.Object3D();let quality='High',night=false;
 const asphalt=new T.MeshStandardMaterial({color:'#626568',roughness:.9}),marking=new T.MeshStandardMaterial({color:'#ddd9c6',roughness:.85});
 const walls=new T.MeshStandardMaterial({vertexColors:true,roughness:.89}),roofMat=new T.MeshStandardMaterial({vertexColors:true,roughness:.9});
 const facadeUniform={value:0};
 walls.onBeforeCompile=s=>{s.uniforms.night=facadeUniform;s.vertexShader='varying vec3 wp;\n'+s.vertexShader;s.vertexShader=s.vertexShader.replace('#include <worldpos_vertex>','#include <worldpos_vertex>\nwp=(modelMatrix*vec4(transformed,1.0)).xyz;');s.fragmentShader='varying vec3 wp;uniform float night;\n'+s.fragmentShader;s.fragmentShader=s.fragmentShader.replace('#include <color_fragment>',`#include <color_fragment>
 float grain=fract(sin(dot(floor(wp*24.),vec3(12.9,78.2,31.7)))*43758.5);diffuseColor.rgb*=.92+grain*.12;
 vec2 cell=vec2((length(vec2(dFdx(wp.x),dFdy(wp.x)))>length(vec2(dFdx(wp.z),dFdy(wp.z)))?wp.x:wp.z),wp.y);vec2 f=fract(cell/vec2(3.5,3.1));float win=step(.22,f.x)*step(f.x,.66)*step(.3,f.y)*step(f.y,.78)*step(1.5,wp.y);diffuseColor.rgb=mix(diffuseColor.rgb,vec3(.11,.19,.21),win);
 totalEmissiveRadiance+=vec3(1.,.64,.25)*win*night*.65*step(.6,fract(sin(dot(floor(cell/3.2),vec2(15.7,37.9)))*4638.));`);};
 asphalt.onBeforeCompile=s=>{s.vertexShader='varying vec3 wp;\n'+s.vertexShader;s.vertexShader=s.vertexShader.replace('#include <worldpos_vertex>','#include <worldpos_vertex>\nwp=(modelMatrix*vec4(transformed,1.)).xyz;');s.fragmentShader='varying vec3 wp;\n'+s.fragmentShader;s.fragmentShader=s.fragmentShader.replace('#include <color_fragment>','#include <color_fragment>\ndiffuseColor.rgb*=.83+.25*fract(sin(dot(floor(wp.xz*35.),vec2(12.98,78.23)))*43758.5);');};
 const palette=['#d1c5ac','#ddd8c5','#b3c1b7','#c4b0a2','#b9b9b0','#c3cacc'].map(c=>new T.Color(c));
 function mesh(verts,material,colors,group){if(!verts.length)return;const g=new T.BufferGeometry();g.setAttribute('position',new T.Float32BufferAttribute(verts,3));if(colors)g.setAttribute('color',new T.Float32BufferAttribute(colors,3));g.computeVertexNormals();const m=new T.Mesh(g,material);m.receiveShadow=true;m.castShadow=material===walls;group.add(m);return m;}
 function quad(v,a,b,c,d){v.push(...a,...c,...b,...a,...d,...c);}
 const ocean=new T.MeshStandardMaterial({color:'#467d88',roughness:.25,metalness:.35});
 const waterGroup=new T.Group();scene.add(waterGroup);const wv=[];
 for(const p of data.water){const points=[];for(let i=0;i<p.length;i+=2)points.push(new T.Vector2(p[i],p[i+1]));for(const tri of T.ShapeUtils.triangulateShape(points,[]))for(const i of tri)wv.push(points[i].x,.04,points[i].y);}
 // OSM coastline direction has land on its left; the sea is southwest here.
 for(const p of data.coast)for(let i=2;i<p.length;i+=2){const a=[p[i-2],.02,p[i-1]],b=[p[i],.02,p[i+1]];quad(wv,a,b,[b[0]-16000,.02,b[2]+8000],[a[0]-16000,.02,a[2]+8000]);}
 ocean.side=T.DoubleSide;mesh(wv,ocean,null,waterGroup);
 const trunkMat=new T.MeshStandardMaterial({color:'#857562',roughness:1}),leafMat=new T.MeshStandardMaterial({color:'#486d45',side:T.DoubleSide,roughness:.9});
 const trunkGeo=new T.CylinderGeometry(.18,.32,10,7),leafVerts=[];
   for(let a=0;a<11;a++){const ang=a*Math.PI*2/11,length=4.2+(a%3)*.4;for(let t=0;t<18;t++){const u=(t+1)/19,rad=u*length,y=Math.sin(u*Math.PI)*1.1-u*u*2.4;for(const side of[-1,1]){const width=Math.sin(u*Math.PI)*.72,px=Math.sin(ang)*rad,pz=Math.cos(ang)*rad;leafVerts.push(px,y,pz,px+Math.cos(ang)*width*side-Math.sin(ang)*.32,y-.28,pz-Math.sin(ang)*width*side-Math.cos(ang)*.32,px+Math.sin(ang)*.15,y-.045,pz+Math.cos(ang)*.15);}}}
const leafGeo=new T.BufferGeometry();leafGeo.setAttribute('position',new T.Float32BufferAttribute(leafVerts,3));leafGeo.computeVertexNormals();
 function build(key){const chunk=data.chunks[key];if(!chunk)return;const [cx,cz]=key.split(',').map(Number),ox=cx*size,oz=cz*size,g=new T.Group(),rv=[],lv=[],bv=[],bc=[],tv=[],tc=[],palms=[];
 for(const [ri,i]of chunk.r){const r=data.roads[ri],a=data.nodes[r.p[i-1]],b=data.nodes[r.p[i]],dx=b[0]-a[0],dz=b[1]-a[1],len=Math.hypot(dx,dz);if(len<.1)continue;const nx=-dz/len,nz=dx/len,half=r.w/2;
 const strip=(offset,width,y,verts,t0=0,t1=1)=>{const ax=a[0]+dx*t0+nx*offset,az=a[1]+dz*t0+nz*offset,bx=a[0]+dx*t1+nx*offset,bz=a[1]+dz*t1+nz*offset;quad(verts,[ax+nx*width/2,y,az+nz*width/2],[bx+nx*width/2,y,bz+nz*width/2],[bx-nx*width/2,y,bz-nz*width/2],[ax-nx*width/2,y,az-nz*width/2]);};
 strip(0,r.w,.09,rv);if(r.w>=6){strip(-half+.25,.12,.105,lv);strip(half-.25,.12,.105,lv);for(let d=0;d<len;d+=12)strip(0,.14,.11,lv,d/len,Math.min(d+4,len)/len);}
 if(len>35)for(let d=18;d<len;d+=65)for(const s of[-1,1]){const x=a[0]+dx*d/len+nx*(half+8)*s,z=a[1]+dz*d/len+nz*(half+8)*s;if(treeClear(x,z)&&!buildingAt(x,z,1))palms.push([x,z]);}
 }
 for(const b of buildings(key)){const h=b[0],col=palette[b[1]],p=b.slice(2),points=[];for(let i=0;i<p.length;i+=2)points.push(new T.Vector2(p[i]+ox,p[i+1]+oz));for(let i=0;i<points.length;i++){const a=points[i],b=points[(i+1)%points.length];const before=bv.length;quad(bv,[a.x,0,a.y],[b.x,0,b.y],[b.x,h,b.y],[a.x,h,a.y]);for(let j=before;j<bv.length;j+=3)bc.push(col.r,col.g,col.b);}for(const tri of T.ShapeUtils.triangulateShape(points,[]))for(const i of tri){tv.push(points[i].x,h,points[i].y);tc.push(col.r*.7,col.g*.69,col.b*.65);}}
 walls.side=T.DoubleSide;roofMat.side=T.DoubleSide;asphalt.side=T.DoubleSide;marking.side=T.DoubleSide;mesh(rv,asphalt,null,g);mesh(lv,marking,null,g);mesh(bv,walls,bc,g);mesh(tv,roofMat,tc,g);
 if(palms.length){const trunks=new T.InstancedMesh(trunkGeo,trunkMat,palms.length),leaves=new T.InstancedMesh(leafGeo,leafMat,palms.length);palms.forEach(([x,z],i)=>{const height=.8+((Math.abs(x*13+z*7)%100)/100)*.45;dummy.rotation.set(0,(x+z)%6.28,0);dummy.scale.set(1,height,1);dummy.position.set(x,5*height,z);dummy.updateMatrix();trunks.setMatrixAt(i,dummy.matrix);dummy.position.y=10*height;dummy.scale.setScalar(.85+height*.15);dummy.updateMatrix();leaves.setMatrixAt(i,dummy.matrix);});trunks.castShadow=leaves.castShadow=true;g.add(trunks,leaves);}
 scene.add(g);loaded.set(key,g);
 }
 const collisionCache=new Map();
 function buildingAt(x,z,r=.7){const cx=Math.floor(x/size),cz=Math.floor(z/size);for(let a=cx-1;a<=cx+1;a++)for(let b=cz-1;b<=cz+1;b++){const key=a+','+b;if(!collisionCache.has(key)){collisionCache.set(key,buildings(key).map(p=>{const poly=p.slice(2),xs=poly.filter((_,i)=>i%2===0),zs=poly.filter((_,i)=>i%2===1);return{poly,minx:Math.min(...xs),maxx:Math.max(...xs),minz:Math.min(...zs),maxz:Math.max(...zs)};}));}const xx=x-a*size,zz=z-b*size;for(const p of collisionCache.get(key)){if(xx<p.minx-r||xx>p.maxx+r||zz<p.minz-r||zz>p.maxz+r)continue;if(pointInPolygon(xx,zz,p.poly)||r&&([[r,0],[-r,0],[0,r],[0,-r]].some(([dx,dz])=>pointInPolygon(xx+dx,zz+dz,p.poly))))return true;}}return false;}
 function isWater(x,z){for(const p of data.water){if(pointInPolygon(x,z,p))return true;}let nearest=null;for(const p of data.coast)for(let i=2;i<p.length;i+=2){const a=[p[i-2],p[i-1]],b=[p[i],p[i+1]],hit=nearestSegment(x,z,a,b);if(!nearest||hit.d<nearest.d)nearest={...hit,sea:(b[0]-a[0])*(z-hit.z)-(b[1]-a[1])*(x-hit.x)>0};}return nearest?.sea&&nearest.d>5;}
 return{buildingAt,isWater,get removedBuildings(){return removedBuildings;},update(x,z){const cx=Math.floor(x/size),cz=Math.floor(z/size),range=quality==='Low'?1:2,wanted=new Set();for(let a=cx-range;a<=cx+range;a++)for(let b=cz-range;b<=cz+range;b++)wanted.add(a+','+b);for(const[key,g]of loaded)if(!wanted.has(key)){scene.remove(g);g.traverse(o=>{if(o.geometry&&![trunkGeo,leafGeo].includes(o.geometry))o.geometry.dispose();});loaded.delete(key);}let count=0;for(const key of wanted)if(!loaded.has(key)&&data.chunks[key]){build(key);if(++count>=2)break;}},setQuality(q){quality=q;},setRain(v){asphalt.roughness=v?.3:.9;},setNight(v){night=v;facadeUniform.value=v?1:0;},get loaded(){return loaded.size},dispose(){for(const g of loaded.values())scene.remove(g);scene.remove(waterGroup);[asphalt,marking,walls,roofMat,ocean,trunkMat,leafMat,trunkGeo,leafGeo,box].forEach(m=>m.dispose());}};
}
