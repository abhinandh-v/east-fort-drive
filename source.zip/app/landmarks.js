import * as T from 'three';
// Original architectural interpretations; the gopuram is positioned from its OSM footprint.
export function addLandmarks(scene,data,network){
 const root=new T.Group();scene.add(root);const geo=new T.BoxGeometry(1,1,1),materials=new Map();
 function box(x,y,z,w,h,d,color){if(!materials.has(color))materials.set(color,new T.MeshStandardMaterial({color,roughness:.85}));const m=new T.Mesh(geo,materials.get(color));m.position.set(x,y,z);m.scale.set(w,h,d);m.castShadow=m.receiveShadow=true;root.add(m);return m;}
 const project=(lat,lon)=>[(lon-data.origin[1])*111320*Math.cos(data.origin[0]*Math.PI/180),(data.origin[0]-lat)*111320];
 const [x,z]=project(8.482766,76.944416);
 for(let level=0;level<7;level++){const w=32-level*3.2,d=18-level*1.4,y=8+level*4.4;box(x,y,z,d,3.9,w,'#d8bd88');box(x,y+2,z,d+1.1,.55,w+1.4,'#eed6a3');for(let j=-w/2+1.5;j<w/2-1;j+=2.9){box(x+d/2+.2,y,z+j,.7,2,1.3,'#b9a073');box(x+d/2+.5,y+1.3,z+j,.9,.4,1.7,'#f0d9ab');}}
 for(let j=-2;j<=2;j++)box(x,38.8,z+j*2.3,1.1,1.5,1.1,'#d9b568');
 const gate=network.nearest(-20,0),g=new T.Group();root.add(g);g.position.set(gate.x,0,gate.z);g.rotation.y=gate.angle;
 for(const side of[-1,1]){const b=box(0,0,0,4,8.5,4.5,'#e8e4d4');root.remove(b);g.add(b);b.position.set(side*(gate.road.w/2+3),4.25,0);const cap=box(0,0,0,5,1.1,5.3,'#f2ebd7');root.remove(cap);g.add(cap);cap.position.set(side*(gate.road.w/2+3),8.7,0);}
 const lintel=box(0,0,0,gate.road.w+10,2.2,3.8,'#f2ead5');root.remove(lintel);g.add(lintel);lintel.position.set(0,9,0);
 function sign(text,lat,lon){const p=network.nearest(...project(lat,lon)),c=document.createElement('canvas');c.width=1024;c.height=128;const ctx=c.getContext('2d');ctx.fillStyle='#184943';ctx.fillRect(0,0,1024,128);ctx.strokeStyle='#edf1d8';ctx.lineWidth=5;ctx.strokeRect(8,8,1008,112);ctx.font='bold 50px Arial';ctx.textAlign='center';ctx.fillStyle='#fff9db';ctx.fillText(text,512,82,970);const tex=new T.CanvasTexture(c);tex.colorSpace=T.SRGBColorSpace;const m=new T.Mesh(new T.PlaneGeometry(11,1.375),new T.MeshStandardMaterial({map:tex,side:T.DoubleSide,roughness:.8}));const xx=p.x+Math.cos(p.angle)*(p.road.w/2+2),zz=p.z-Math.sin(p.angle)*(p.road.w/2+2);m.position.set(xx,5.1,zz);m.rotation.y=p.angle;root.add(m);box(xx,2.1,zz,.12,4.2,.12,'#7c8582');}
 sign('EAST FORT',8.48275,76.94765);sign('CHALAI MARKET',8.4821,76.953);sign('NAPIER MUSEUM',8.50884,76.95487);sign('NH 66 · KULATHOOR',8.514,76.898);sign('THIRUVALLAM',8.44,76.954);
 return root;
}
