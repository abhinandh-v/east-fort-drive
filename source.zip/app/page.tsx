'use client';
import {useEffect,useRef,useState} from 'react';
import {startGame} from './world';
export default function Home(){
 const mount=useRef<HTMLDivElement>(null),api=useRef<any>(null);
 const [h,setH]=useState({speed:0,mode:'Driving',place:'East Fort',mission:'Explore the neighborhood',step:0,active:false,paused:false,night:false});
 const [error,setError]=useState('');
 useEffect(()=>{try{api.current=startGame(mount.current!,setH)}catch(e){setError('Unable to start the 3D world. Please enable WebGL in your browser.');console.error(e)}return()=>api.current?.dispose()},[]);
 const act=(s:string)=>api.current?.action(s);
 return <main className="game"><div ref={mount} className="viewport" aria-label="3D East Fort game world"/>
 <header className="topbar"><div className="brand"><b className="logo">E/F</b><div><h1>EAST FORT <em>DRIVE</em></h1><p>THIRUVANANTHAPURAM · KERALA</p></div></div><div className="top-actions"><span>● OPEN WORLD</span><button onClick={()=>act('night')}>{h.night?'☾ Night':'☀ Golden hour'}</button><button onClick={()=>act('pause')}>{h.paused?'Resume':'Pause'}</button></div></header>
 <aside className="mission"><div className="eyebrow">{h.active?'DELIVERY RUN':'THE CITY IS YOURS'}</div><h2>{h.active?h.mission:'Take the long way home.'}</h2><p>{h.active?'Follow the amber marker. Stop inside it to deliver.':'Cruise the temple approach, turn into Chalai, or step out and explore.'}</p><button className="primary" onClick={()=>act('mission')}>{h.active?'Cancel delivery':'Start a delivery'} <span>↗</span></button>{h.active&&<p className="progress">STOP {h.step+1} OF 3</p>}</aside>
 <div className="location"><span>08.48° N &nbsp; 76.95° E</span><h2>{h.place}</h2><p>{h.mode} · Free roam</p></div>
 <div className="map-panel"><canvas id="minimap" width="240" height="200" aria-label="Neighborhood map, player and destination"/><div>NEIGHBORHOOD MAP <b>N ↑</b></div></div>
 <div className="speed"><strong>{String(h.speed).padStart(2,'0')}</strong><span>{h.mode==='Driving'?'KM/H':'ON FOOT'}</span></div>
 <nav className="controls" aria-label="Game controls"><span><kbd>W A S D</kbd> Move</span><span><kbd>SPACE</kbd> Brake</span><button onClick={()=>act('enter')}><kbd>F</kbd>{h.mode==='Driving'?'Exit car':'Enter nearby car'}</button><button onClick={()=>act('camera')}><kbd>C</kbd> Camera</button><button onClick={()=>act('reset')}><kbd>R</kbd> Recover</button></nav>
 <div className="touch-controls"><div>{[['↑','w'],['←','a'],['↓','s'],['→','d']].map(([label,key])=><button key={key} aria-label={'Move '+key} onPointerDown={e=>{e.currentTarget.setPointerCapture(e.pointerId);api.current?.key(key,true)}} onPointerUp={()=>api.current?.key(key,false)} onPointerCancel={()=>api.current?.key(key,false)}>{label}</button>)}</div><button onPointerDown={e=>{e.currentTarget.setPointerCapture(e.pointerId);api.current?.key(' ',true)}} onPointerUp={()=>api.current?.key(' ',false)} onPointerCancel={()=>api.current?.key(' ',false)}>BRAKE</button></div>
 {h.paused&&<div className="pause-label">PAUSED<button onClick={()=>act('pause')}>Return to the streets</button></div>}{error&&<div className="pause-label" role="alert">{error}</div>}
 <details className="credits"><summary>About this world</summary><p>Playable stylized prototype. Roads, buildings and distances are approximate, not a complete surveyed recreation. Original procedural 3D assets; no Google imagery embedded.</p><p>Reference: <a href="https://www.google.com/maps/search/?api=1&query=East+Fort+Thiruvananthapuram" target="_blank" rel="noreferrer">Google Maps: East Fort</a>. Street View could not be verified in this build.</p><p>Arrow keys also move. F enters/exits a nearby car. C changes camera. R recovers to the road. Esc pauses. Keyboard recommended; touch buttons supported.</p></details></main>
}
