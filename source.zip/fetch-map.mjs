import fs from 'node:fs/promises';
const q='[out:json][timeout:150];(way[highway~"^(motorway|trunk|primary|secondary|tertiary|unclassified|residential|living_street|motorway_link|trunk_link|primary_link|secondary_link|tertiary_link)$"](around:10200,8.48275,76.94765);way[building](around:10000,8.48275,76.94765);way[natural=water](around:10000,8.48275,76.94765);way[natural=coastline](around:12000,8.48275,76.94765););out geom;';
const r=await fetch('https://maps.mail.ru/osm/tools/overpass/api/interpreter?data='+encodeURIComponent(q));
if(!r.ok)throw new Error('Overpass '+r.status);
const text=await r.text(); const data=JSON.parse(text); if(!data.elements?.length)throw new Error('Empty map');
await fs.writeFile(process.argv[2]||'map-raw.json',text);console.log(data.elements.length+' map features; '+text.length+' bytes');




