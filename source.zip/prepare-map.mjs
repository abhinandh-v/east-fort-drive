import fs from 'node:fs/promises';
// OSM-derived database: distributed under ODbL 1.0 with the public game.
const raw=JSON.parse(await fs.readFile(process.argv[2]||'map-raw.json','utf8'));
const origin=[8.48275,76.94765], radius=10000, size=500, nodes=[], nodeMap=new Map(), roads=[], chunks={};
const project=p=>[Math.round((p.lon-origin[1])*111320*Math.cos(origin[0]*Math.PI/180)),Math.round((origin[0]-p.lat)*111320)];
const chunk=(x,z)=>{const key=Math.floor(x/size)+','+Math.floor(z/size);return chunks[key]??= {b:[],r:[]}};
const defaults={motorway:10,trunk:9,primary:9,secondary:8,tertiary:7,unclassified:6,residential:5,living_street:5};
for(const e of raw.elements){if(!e.tags.highway||e.tags.access==='private'||e.tags.access==='no')continue;
 const t=e.tags;let run=[];
 const flush=()=>{if(run.length>1){const ri=roads.length;const kind=t.highway.replace('_link','');roads.push({id:e.id,p:run,w:Math.max(4,Math.min(16,parseFloat(t.width)||((+t.lanes||0)*3.3)||defaults[kind]||6)),highway:/^(trunk|motorway)/.test(t.highway),name:t['name:en']||t.name||t.ref||(kind==='residential'?'Local street':kind+' road'),oneway:t.oneway==='yes'?1:t.oneway==='-1'?-1:0});for(let i=1;i<run.length;i++){const a=nodes[run[i-1]],b=nodes[run[i]];chunk((a[0]+b[0])/2,(a[1]+b[1])/2).r.push([ri,i]);}}run=[];};
 e.geometry.forEach((p,i)=>{const xy=project(p);if(Math.hypot(...xy)>9990){flush();return;}const id=e.nodes[i];if(!nodeMap.has(id)){nodeMap.set(id,nodes.length);nodes.push(xy);}run.push(nodeMap.get(id));});flush();
}
let buildings=0;const water=[],coast=[];
for(const e of raw.elements){const g=e.geometry?.map(project);if(!g?.length)continue;
 if(e.tags.building){let x=0,z=0;g.forEach(p=>{x+=p[0];z+=p[1]});x/=g.length;z/=g.length;if(Math.hypot(x,z)>radius)continue;const cx=Math.floor(x/size)*size,cz=Math.floor(z/size)*size;const poly=g.slice(0,-1).filter((p,i,a)=>!i||p[0]!==a[i-1][0]||p[1]!==a[i-1][1]);if(poly.length<3)continue;const height=Math.max(3,Math.min(65,parseFloat(e.tags.height)||(+e.tags['building:levels']||(/apartments|commercial/.test(e.tags.building)?3:1+(e.id%3)))*3.1));chunk(x,z).b.push([Math.round(height*10)/10,e.id%6,...poly.flatMap(p=>[p[0]-cx,p[1]-cz])]);buildings++;}
 else if(e.tags.natural==='water'&&g.length>3)water.push(g.flat());
 else if(e.tags.natural==='coastline')coast.push(g.flat());
}
const data={origin,radius,size,source:'© OpenStreetMap contributors · ODbL 1.0',date:new Date().toISOString().slice(0,10),nodes,roads,chunks,water,coast,stats:{roads:roads.length,buildings}};
await fs.writeFile('assets/region.json',JSON.stringify(data));
console.log(JSON.stringify({...data.stats,nodes:nodes.length,chunks:Object.keys(chunks).length,bytes:JSON.stringify(data).length}));

