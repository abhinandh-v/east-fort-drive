import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import {createRoadNetwork,pointInPolygon,nearestSegment} from './app/region.js';
import {resolveJourneys} from './app/journeys.js';
const data=JSON.parse(await fs.readFile('assets/region.json','utf8'));
assert.equal(data.radius,10000);assert(data.stats.roads>19000);assert(data.stats.buildings>160000);
assert(data.nodes.every(p=>Number.isFinite(p[0])&&Number.isFinite(p[1])&&Math.hypot(...p)<=9991));
const network=createRoadNetwork(data),journeys=resolveJourneys(data,network);
assert(network.connected.size>100000,'Most roads are in the playable connected network');
for(const j of journeys){let start=network.nearest(0,0),total=0;for(const stop of j.stops){assert(Math.hypot(stop.x,stop.z)<10000);const route=network.route(start,stop);assert(route&&route.points.length,'Every stop is reachable');assert(route.points.every(p=>Math.hypot(...p)<10000));total+=route.length;start=stop;}console.log(j.name+': '+(total/1000).toFixed(2)+' km, '+j.stops.length+' reachable stops');}
assert(network.nearest(-2600,-1500,true).road.highway,'Highway quick travel snaps to NH66');
assert(pointInPolygon(5,5,[0,0,10,0,10,10,0,10]));assert(!pointInPolygon(15,5,[0,0,10,0,10,10,0,10]));assert.equal(nearestSegment(5,5,[0,0],[10,0]).d,5);
console.log('PASS: 10 km boundary, real dataset, connected routes, eight journeys, highway access and collision helpers.');
