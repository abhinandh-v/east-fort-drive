$ErrorActionPreference = 'Stop'
New-Item -ItemType Directory -Force dist | Out-Null
$gameCompiler = Get-ChildItem node_modules/.pnpm -Filter esbuild.exe -Recurse | Select-Object -First 1 -ExpandProperty FullName
if (-not $gameCompiler) { throw 'Install dependencies before building.' }
& $gameCompiler app/client.tsx --bundle --minify --format=esm --platform=browser --jsx=automatic '--define:process.env.NODE_ENV="production"' --outfile=dist/game.js
if ($LASTEXITCODE -ne 0) { throw 'Game compilation failed.' }
Copy-Item index.html dist/index.html
$gameStyle = Get-Content app/globals.css -Raw
$gameStyle.Replace("@import 'tailwindcss';", '') | Set-Content dist/style.css
Copy-Item node_modules/three/LICENSE dist/THREE-LICENSE.txt
Copy-Item node_modules/react/LICENSE dist/REACT-LICENSE.txt
Copy-Item node_modules/react-dom/LICENSE dist/REACT-DOM-LICENSE.txt
Copy-Item assets/* dist/
Write-Output 'Production browser game built successfully.'
