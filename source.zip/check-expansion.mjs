import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import * as Three from 'three';
let scene,frame,hud,tool,renderCamera;
class TestRenderer{constructor(){this.shadowMap={};this.domElement={remove(){}}}setPixelRatio(){}setSize(){}render(s,c){scene=s;renderCamera=c;}dispose(){}}
globalThis.__testThree={...Three,WebGLRenderer:TestRenderer};
const ctx=new Proxy({createLinearGradient:()=>({addColorStop(){}})},{get:(o,k)=>o[k]??(()=>{}),set:(o,k,v)=>(o[k]=v,true)});
globalThis.document={createElement:()=>({getContext:()=>ctx}),getElementById:()=>({width:280,height:200,getContext:()=>ctx}),modelContext:{registerTool(t){tool=t}}};
globalThis.window={addEventListener(){},removeEventListener(){}};globalThis.devicePixelRatio=1;globalThis.localStorage={getItem(){return null;},setItem(){}};
globalThis.requestAnimationFrame=fn=>(frame=fn,1);globalThis.cancelAnimationFrame=()=>{};
const data=JSON.parse(await readFile('assets/region.json','utf8'));globalThis.fetch=async url=>{if(url==='./region.json')return{ok:true,json:async()=>data};throw Error('No remote assets in mock test');};
let src=(await readFile('app/expansion.js','utf8')).replace("import * as T from 'three';","const T=globalThis.__testThree;");src=src.replace(/from '(\.\/[^']+)'/g,(_,p)=>'from '+JSON.stringify(new URL('./app/'+p.slice(2),import.meta.url).href));src=src.replace("'three/addons/loaders/RGBELoader.js'",JSON.stringify(import.meta.resolve('three/addons/loaders/RGBELoader.js')));
const {startGame}=await import('data:text/javascript;base64,'+Buffer.from(src).toString('base64'));const api=startGame({clientWidth:1280,clientHeight:800,appendChild(){}},h=>hud=h);await api.ready;assert(!hud.loading&&!hud.error);
let time=performance.now();const advance=n=>{for(let i=0;i<n;i++)frame(time+=1000/60);};advance(2);const start=api.getSnapshot();api.key('w',true);advance(50);api.key('w',false);assert(api.getSnapshot().distance>0,'Vehicle moves at real world meter scale');
api.action('highway');assert(Math.hypot(api.getSnapshot().x,api.getSnapshot().z)>1000,'Highway quick travel leaves old neighborhood');api.action('reset');assert.equal(api.getSnapshot().condition,100);
api.action('enter');assert.equal(api.getSnapshot().mode,'Walking');api.action('enter');assert.equal(api.getSnapshot().mode,'Driving');
api.action('driver');advance(2);assert.equal(api.getSnapshot().cam,4);const car=scene.children.find(o=>o.name==='Defender 110 inspired SUV'),eye=car.children[0].localToWorld(new Three.Vector3(-.51,2.04,.48));assert(renderCamera.position.distanceTo(eye)<.001,'Driver camera stays in the seat without chase lag');const forward=new Three.Vector3(0,0,1).transformDirection(car.matrixWorld);assert(renderCamera.getWorldDirection(new Three.Vector3()).dot(forward)>.99,'Driver looks forward through the windshield');assert.equal(renderCamera.near,.035);api.action('camera');advance(2);assert.equal(api.getSnapshot().cam,0);assert.equal(renderCamera.near,.12);
for(const j of api.getSnapshot().journeys){api.action('select',j.id);api.action('mission');assert(api.getSnapshot().active);assert(api.getSnapshot().route?.points.length);api.action('mission');assert(!api.getSnapshot().active);}
api.action('map');assert(api.getSnapshot().map);api.action('night');api.action('rain');api.action('quality','Low');assert.equal(api.getSnapshot().quality,'Low');
assert.equal(tool.execute({paused:true}).radius,10000);assert.throws(()=>tool.execute({paused:'yes'}));const x=api.getSnapshot().x;api.key('w',true);advance(30);assert.equal(api.getSnapshot().x,x);api.key('w',false);tool.execute({paused:false});api.action('home');assert(Math.hypot(api.getSnapshot().x,api.getSnapshot().z)<50);api.dispose();console.log('PASS: regional game initialization, driving, highway travel, recovery, enter/exit, all mission starts, map, weather, quality, pause and cleanup (mock renderer).');
